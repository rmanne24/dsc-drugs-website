/**
 * GLOBAL PRESENCE DATA — ILLUSTRATIVE PLACEHOLDERS
 * ------------------------------------------------------------------
 * DSC Drugs has not supplied verified market data. The hubs below exist
 * only to demonstrate the interactive map and must not be presented as
 * confirmed markets. Replace with verified locations and remove
 * `illustrative: true` once approved.
 */

export type Market = {
  id: string;
  label: string;
  region: string;
  coords: [number, number]; // [lat, lon]
  note: string;
  illustrative: boolean;
};

export const markets: Market[] = [
  {
    id: "hub-01",
    label: "Hub 01",
    region: "Middle East",
    coords: [25.2, 55.27],
    note: "Illustrative location used to preview the market panel. Verified market details to follow.",
    illustrative: true,
  },
  {
    id: "hub-02",
    label: "Hub 02",
    region: "South Asia",
    coords: [19.08, 72.88],
    note: "Illustrative location used to preview the market panel. Verified market details to follow.",
    illustrative: true,
  },
  {
    id: "hub-03",
    label: "Hub 03",
    region: "Southeast Asia",
    coords: [1.35, 103.82],
    note: "Illustrative location used to preview the market panel. Verified market details to follow.",
    illustrative: true,
  },
  {
    id: "hub-04",
    label: "Hub 04",
    region: "Europe",
    coords: [51.51, -0.13],
    note: "Illustrative location used to preview the market panel. Verified market details to follow.",
    illustrative: true,
  },
  {
    id: "hub-05",
    label: "Hub 05",
    region: "Africa",
    coords: [-1.29, 36.82],
    note: "Illustrative location used to preview the market panel. Verified market details to follow.",
    illustrative: true,
  },
  {
    id: "hub-06",
    label: "Hub 06",
    region: "Latin America",
    coords: [-23.55, -46.63],
    note: "Illustrative location used to preview the market panel. Verified market details to follow.",
    illustrative: true,
  },
];

/** Routes drawn between hubs — purely illustrative connection lines. */
export const routes: [string, string][] = [
  ["hub-01", "hub-02"],
  ["hub-01", "hub-04"],
  ["hub-02", "hub-03"],
  ["hub-01", "hub-05"],
  ["hub-04", "hub-06"],
  ["hub-03", "hub-06"],
];

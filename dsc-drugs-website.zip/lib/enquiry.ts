import { enquiryTypes } from "@/lib/site";

export type EnquiryPayload = {
  name: string;
  email: string;
  company: string;
  country: string;
  type: string;
  product: string;
  message: string;
  /** Honeypot — must stay empty. */
  website?: string;
};

export type FieldErrors = Partial<Record<"name" | "email" | "message" | "type", string>>;

const EMAIL_RE = /^[^\s@<>()[\]\\,;:]+@[^\s@<>()[\]\\,;:]+\.[a-zA-Z]{2,}$/;

const str = (value: unknown, max = 400) => (typeof value === "string" ? value.trim().slice(0, max) : "");

export function normaliseEnquiry(body: unknown): EnquiryPayload {
  const raw = (body ?? {}) as Record<string, unknown>;
  return {
    name: str(raw.name, 120),
    email: str(raw.email, 160),
    company: str(raw.company, 160),
    country: str(raw.country, 80),
    type: str(raw.type, 60),
    product: str(raw.product, 160),
    message: str(raw.message, 4000),
    website: str(raw.website, 200),
  };
}

export function validateEnquiry(data: EnquiryPayload): FieldErrors {
  const errors: FieldErrors = {};

  if (data.name.length < 2) errors.name = "Please share your full name.";
  if (!data.email) errors.email = "An email address is required so we can reply.";
  else if (!EMAIL_RE.test(data.email)) errors.email = "That email address does not look valid.";

  if (data.type && !(enquiryTypes as readonly string[]).includes(data.type)) {
    errors.type = "Please choose one of the listed enquiry types.";
  }

  if (data.message.length < 20) errors.message = "Please add a little more detail (at least 20 characters).";

  return errors;
}

/**
 * Delivery configuration.
 * Production needs ONE of:
 *  - RESEND_API_KEY + ENQUIRY_TO_EMAIL (sent through the Resend REST API)
 *  - ENQUIRY_WEBHOOK_URL (POSTed as JSON to your own endpoint / CRM / automation)
 * Without either, the route validates and accepts the enquiry in development
 * mode and clearly tells the visitor that no message was delivered.
 */
export function deliveryConfig() {
  const resendKey = process.env.RESEND_API_KEY;
  const to = process.env.ENQUIRY_TO_EMAIL;
  const webhook = process.env.ENQUIRY_WEBHOOK_URL;
  const from = process.env.ENQUIRY_FROM_EMAIL ?? "DSC Drugs Website <website@dscdrugs.com>";
  if (webhook) return { mode: "webhook" as const, webhook, from };
  if (resendKey && to) return { mode: "resend" as const, resendKey, to, from };
  return { mode: "development" as const };
}

export async function deliverEnquiry(data: EnquiryPayload): Promise<"delivered" | "development"> {
  const config = deliveryConfig();

  const summary = [
    `Name: ${data.name}`,
    `Email: ${data.email}`,
    `Company: ${data.company || "—"}`,
    `Country: ${data.country || "—"}`,
    `Enquiry type: ${data.type || "—"}`,
    `Product of interest: ${data.product || "—"}`,
    "",
    data.message,
  ].join("\n");

  if (config.mode === "webhook") {
    const response = await fetch(config.webhook, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ source: "dscdrugs.com", receivedAt: new Date().toISOString(), ...data }),
      cache: "no-store",
    });
    if (!response.ok) throw new Error(`Webhook responded ${response.status}`);
    return "delivered";
  }

  if (config.mode === "resend") {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        authorization: `Bearer ${config.resendKey}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        from: config.from,
        to: [config.to],
        reply_to: data.email,
        subject: `Website enquiry — ${data.type || "General"} — ${data.name}`,
        text: summary,
      }),
      cache: "no-store",
    });
    if (!response.ok) throw new Error(`Email provider responded ${response.status}`);
    return "delivered";
  }

  // Development placeholder: log server-side only, never claim delivery.
  console.info("[enquiry:development]", summary);
  return "development";
}

/** Very small in-memory rate limiter — adequate for a single Node instance. */
const hits = new Map<string, number[]>();

export function rateLimit(key: string, limit = 5, windowMs = 15 * 60 * 1000) {
  const now = Date.now();
  const recent = (hits.get(key) ?? []).filter((time) => now - time < windowMs);
  if (recent.length >= limit) {
    hits.set(key, recent);
    return false;
  }
  recent.push(now);
  hits.set(key, recent);
  if (hits.size > 500) {
    for (const [ip, times] of hits) {
      if (!times.some((time) => now - time < windowMs)) hits.delete(ip);
    }
  }
  return true;
}

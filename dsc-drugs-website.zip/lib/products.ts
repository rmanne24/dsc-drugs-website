/**
 * PRODUCT DATA — EDITABLE PLACEHOLDERS
 * ------------------------------------------------------------------
 * The records below are structural placeholders, not real DSC Drugs
 * products. Replace `name`, `summary`, `cas`, `specifications` and
 * `documents` with verified information supplied by the company.
 * Setting `placeholder: false` removes the "Placeholder record" badge.
 */

export type ProductCategory = {
  slug: string;
  name: string;
  short: string;
  description: string;
  art: "molecule" | "vial" | "tablet" | "specialty";
};

export type Product = {
  slug: string;
  name: string;
  category: string;
  categorySlug: string;
  /** Therapeutic or sourcing segment, editable */
  segment: string;
  cas: string | null;
  summary: string;
  overview: string;
  specifications: { label: string; value: string }[];
  documents: { label: string; status: "provided" | "on-request" | "not-available" }[];
  placeholder: boolean;
  featured?: boolean;
};

export const categories: ProductCategory[] = [
  {
    slug: "apis-intermediates",
    name: "APIs & Intermediates",
    short: "Active ingredients and intermediates sourced through qualified trade partners.",
    description:
      "A trading category covering active pharmaceutical ingredients and intermediates. Product-level data, sourcing origins and documentation are published only once verified.",
    art: "molecule",
  },
  {
    slug: "injectables",
    name: "Injectables",
    short: "Sterile injectable formats supplied to healthcare and distribution partners.",
    description:
      "A trading category covering injectable formats. Availability, presentation and documentation are confirmed per enquiry with our commercial team.",
    art: "vial",
  },
  {
    slug: "oral-solids",
    name: "Oral Solids",
    short: "Tablet and capsule formats for distribution and institutional supply.",
    description:
      "A trading category covering oral solid dosage formats. Catalogue data is published after commercial and documentation review.",
    art: "tablet",
  },
  {
    slug: "specialty-products",
    name: "Specialty Products",
    short: "Focused therapeutic categories requiring tailored commercial handling.",
    description:
      "A trading category for specialty requirements handled through partner-led sourcing and documentation review.",
    art: "specialty",
  },
];

export const categoryBySlug = (slug: string) => categories.find((c) => c.slug === slug);

/** null fields render as "To be confirmed" rather than invented data. */
export const products: Product[] = [
  {
    slug: "portfolio-entry-01",
    name: "Portfolio Entry 01",
    category: "APIs & Intermediates",
    categorySlug: "apis-intermediates",
    segment: "Active ingredient",
    cas: null,
    summary:
      "Placeholder catalogue record. Product name, CAS number and specification will be published once verified by DSC Drugs.",
    overview:
      "This record demonstrates the catalogue template. Replace it with verified product information — name, CAS number, approved specification, documentation availability and commercial notes.",
    specifications: [],
    documents: [],
    placeholder: true,
    featured: true,
  },
  {
    slug: "portfolio-entry-02",
    name: "Portfolio Entry 02",
    category: "APIs & Intermediates",
    categorySlug: "apis-intermediates",
    segment: "Intermediate",
    cas: null,
    summary:
      "Placeholder catalogue record for an intermediate sourced through trade partners.",
    overview:
      "This record demonstrates the catalogue template. Verified technical details should be added before publication.",
    specifications: [],
    documents: [],
    placeholder: true,
    featured: true,
  },
  {
    slug: "portfolio-entry-03",
    name: "Portfolio Entry 03",
    category: "Injectables",
    categorySlug: "injectables",
    segment: "Sterile injectable",
    cas: null,
    summary:
      "Placeholder catalogue record for an injectable presentation. Availability confirmed on enquiry.",
    overview:
      "This record demonstrates the catalogue template. Presentation, pack size and documentation should be supplied by the company.",
    specifications: [],
    documents: [],
    placeholder: true,
    featured: true,
  },
  {
    slug: "portfolio-entry-04",
    name: "Portfolio Entry 04",
    category: "Injectables",
    categorySlug: "injectables",
    segment: "Sterile injectable",
    cas: null,
    summary: "Placeholder catalogue record reserved for a second injectable presentation.",
    overview:
      "This record demonstrates the catalogue template. Verified product details are required before publication.",
    specifications: [],
    documents: [],
    placeholder: true,
  },
  {
    slug: "portfolio-entry-05",
    name: "Portfolio Entry 05",
    category: "Oral Solids",
    categorySlug: "oral-solids",
    segment: "Tablet",
    cas: null,
    summary:
      "Placeholder catalogue record for an oral solid dosage format supplied to distribution partners.",
    overview:
      "This record demonstrates the catalogue template. Strength, pack configuration and documentation are to be confirmed.",
    specifications: [],
    documents: [],
    placeholder: true,
    featured: true,
  },
  {
    slug: "portfolio-entry-06",
    name: "Portfolio Entry 06",
    category: "Oral Solids",
    categorySlug: "oral-solids",
    segment: "Capsule",
    cas: null,
    summary: "Placeholder catalogue record reserved for a capsule presentation.",
    overview:
      "This record demonstrates the catalogue template. Verified product details are required before publication.",
    specifications: [],
    documents: [],
    placeholder: true,
  },
  {
    slug: "portfolio-entry-07",
    name: "Portfolio Entry 07",
    category: "Specialty Products",
    categorySlug: "specialty-products",
    segment: "Specialty",
    cas: null,
    summary:
      "Placeholder catalogue record for a specialty category handled through partner sourcing.",
    overview:
      "This record demonstrates the catalogue template. Sourcing notes and documentation are published only when approved.",
    specifications: [],
    documents: [],
    placeholder: true,
  },
  {
    slug: "portfolio-entry-08",
    name: "Portfolio Entry 08",
    category: "Specialty Products",
    categorySlug: "specialty-products",
    segment: "Specialty",
    cas: null,
    summary: "Placeholder catalogue record reserved for a specialty product requirement.",
    overview:
      "This record demonstrates the catalogue template. Verified product details are required before publication.",
    specifications: [],
    documents: [],
    placeholder: true,
  },
];

export const featuredProducts = products.filter((p) => p.featured);

export const productBySlug = (slug: string) => products.find((p) => p.slug === slug);

export function relatedProducts(product: Product, limit = 3) {
  return products
    .filter((p) => p.slug !== product.slug && p.categorySlug === product.categorySlug)
    .concat(products.filter((p) => p.slug !== product.slug && p.categorySlug !== product.categorySlug))
    .slice(0, limit);
}

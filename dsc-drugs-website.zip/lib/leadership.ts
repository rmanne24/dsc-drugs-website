/**
 * MANAGEMENT DATA — PLACEHOLDERS ONLY
 * ------------------------------------------------------------------
 * No names, titles, biographies or photographs have been supplied.
 * Fill these fields with verified information and set `placeholder: false`
 * to remove the "Profile pending" label. LinkedIn is optional.
 */

export type Leader = {
  id: string;
  name: string | null;
  designation: string | null;
  bio: string | null;
  linkedin: string | null;
  placeholder: boolean;
};

export const leadership: Leader[] = [
  {
    id: "profile-01",
    name: null,
    designation: null,
    bio: null,
    linkedin: null,
    placeholder: true,
  },
  {
    id: "profile-02",
    name: null,
    designation: null,
    bio: null,
    linkedin: null,
    placeholder: true,
  },
  {
    id: "profile-03",
    name: null,
    designation: null,
    bio: null,
    linkedin: null,
    placeholder: true,
  },
];

/**
 * Central site configuration.
 * Replace the placeholder values below with DSC Drugs' verified details
 * before the site goes live. Anything marked `verified: false` is a draft.
 */

export const siteConfig = {
  name: "DSC Drugs",
  legalName: "DSC Drugs",
  tagline: "Pharmaceutical Trading & Global Sourcing",
  description:
    "DSC Drugs is a pharmaceutical trading company connecting pharmaceutical products, business partners and markets across borders.",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://www.dscdrugs.com",
  locale: "en_GB",
  contact: {
    verified: false,
    email: "enquiries@dscdrugs.com",
    phone: "+00 000 000 0000",
    phoneHref: "+00000000000",
    addressLines: ["Registered office address", "City, Country"],
    hours: ["Monday – Friday", "09:00 – 18:00 (local time)"],
  },
  /**
   * WhatsApp requires a full international number without "+" or spaces,
   * e.g. "919876543210". Leave empty until the business number is confirmed —
   * the button then explains that WhatsApp is not yet connected and offers email.
   */
  whatsapp: {
    number: "919542279955",
    displayNumber: "+91 95422 79955",
    verified: true,
  },
  social: {
    linkedin: "",
  },
} as const;

export type NavItem = { label: string; href: string; children?: { label: string; href: string }[] };

export const primaryNav: NavItem[] = [
  { label: "About", href: "/#about" },
  {
    label: "Products",
    href: "/#products",
    children: [
      { label: "All Products", href: "/#catalogue" },
      { label: "Our Portfolio", href: "/#products" },
      { label: "Enquiry List", href: "/#enquiry-list" },
    ],
  },
  { label: "Global Presence", href: "/#global-presence" },
  { label: "Management", href: "/#management" },
  { label: "Quality", href: "/#quality" },
];

export const footerNav = [
  { label: "About", href: "/#about" },
  { label: "Products", href: "/#products" },
  { label: "Global Presence", href: "/#global-presence" },
  { label: "Management", href: "/#management" },
  { label: "Quality", href: "/#quality" },
  { label: "Contact", href: "/#contact" },
];

export const legalNav = [
  { label: "Privacy Policy", href: "/privacy" },
  { label: "Terms of Use", href: "/terms" },
];

export const enquiryTypes = [
  "Product Enquiry",
  "Supply Enquiry",
  "Business Partnership",
  "General Enquiry",
  "Other",
] as const;

export const whatsappMessages = {
  general:
    "Hello DSC Drugs, I visited your website and would like to enquire about your pharmaceutical products and business opportunities. Could you please assist me?",
  product: (product: string) =>
    `Hello DSC Drugs, I would like to enquire about ${product}. Please share more information.`,
};

export function whatsappHref(message: string) {
  if (!siteConfig.whatsapp.number) return "";
  return `https://wa.me/${siteConfig.whatsapp.number}?text=${encodeURIComponent(message)}`;
}

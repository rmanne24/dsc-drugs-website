import Link from "next/link";
import { CategoryArt } from "@/components/Artwork";
import { ArrowUpRight } from "@/components/Icons";
import { EnquiryToggle } from "@/components/EnquiryToggle";
import type { Product } from "@/lib/products";
import { categoryBySlug } from "@/lib/products";

export function ProductCard({ product, index }: { product: Product; index?: number }) {
  const category = categoryBySlug(product.categorySlug);

  return (
    <article className="lift group relative flex h-full flex-col overflow-hidden border border-ink/10 bg-paper">
      <Link
        href={`/products/${product.slug}`}
        className="relative block aspect-[4/3] overflow-hidden bg-ivory-deep zoom-media"
        aria-label={`View ${product.name}`}
      >
        <CategoryArt variant={category?.art ?? "molecule"} />
        <span className="absolute left-4 top-4 flex items-center gap-2 border border-white/40 bg-ink/35 px-2.5 py-1 text-[0.55rem] font-semibold uppercase tracking-[0.16em] text-ivory backdrop-blur-sm">
          {product.placeholder ? "Placeholder record" : category?.name}
        </span>
        <span className="absolute bottom-4 right-4 flex h-9 w-9 items-center justify-center border border-ink/15 bg-paper/90 text-ink opacity-0 transition-all duration-300 group-hover:opacity-100">
          <ArrowUpRight size={15} />
        </span>
      </Link>

      <div className="flex flex-1 flex-col p-5 sm:p-6">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-[0.58rem] font-semibold uppercase tracking-[0.18em] text-jade-deep">
              {category?.name}
            </p>
            <h3 className="mt-2 font-serif text-[1.35rem] font-normal leading-tight text-ink">
              <Link href={`/products/${product.slug}`} className="transition-colors hover:text-jade-deep">
                {product.name}
              </Link>
            </h3>
          </div>
          {typeof index === "number" && (
            <span className="mt-1 font-serif text-sm text-ink/25">
              {String(index + 1).padStart(2, "0")}
            </span>
          )}
        </div>

        <p className="mt-3 line-clamp-2 text-[0.82rem] leading-relaxed text-grey">{product.summary}</p>

        <div className="mt-auto flex items-center justify-between gap-3 pt-5">
          <Link
            href={`/products/${product.slug}`}
            className="inline-flex items-center gap-1.5 text-[0.62rem] font-semibold uppercase tracking-[0.15em] text-ink/70 transition-colors hover:text-ink"
          >
            Details
            <ArrowUpRight size={12} />
          </Link>
          <EnquiryToggle slug={product.slug} name={product.name} category={category?.name ?? product.category} />
        </div>
      </div>
    </article>
  );
}

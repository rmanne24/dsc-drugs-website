import Link from "next/link";

type LogoProps = {
  tone?: "light" | "dark";
  className?: string;
  asLink?: boolean;
  showTagline?: boolean;
};

/**
 * Brand mark.
 * NOTE: The official DSC Drugs logo artwork was not included with the brief.
 * This mark uses the brand's teal, jade and mint language as a stand-in and
 * can be replaced by dropping the supplied SVG into `public/brand/` and
 * swapping the <svg> below for an <Image>.
 */
export function Logo({ tone = "light", asLink = true, showTagline = true, className }: LogoProps) {
  const ink = tone === "light" ? "#F3F4F0" : "#0B2223";
  const muted = tone === "light" ? "rgba(243,244,240,0.55)" : "rgba(11,34,35,0.55)";
  const ring = tone === "light" ? "rgba(169,209,197,0.55)" : "rgba(11,34,35,0.35)";

  const content = (
    <span className={`flex items-center gap-3 ${className ?? ""}`}>
      <svg width="38" height="38" viewBox="0 0 38 38" fill="none" aria-hidden="true" className="shrink-0">
        <circle cx="19" cy="19" r="18" stroke={ring} strokeWidth="0.9" />
        <ellipse cx="19" cy="19" rx="8.1" ry="17.4" stroke={ring} strokeWidth="0.75" />
        <path d="M1.6 19h34.8" stroke={ring} strokeWidth="0.75" />
        <path d="M4.3 11.2c4 2.2 9.2 3.4 14.7 3.4s10.7-1.2 14.7-3.4" stroke={ring} strokeWidth="0.75" />
        <path d="M4.3 26.8c4-2.2 9.2-3.4 14.7-3.4s10.7 1.2 14.7 3.4" stroke={ring} strokeWidth="0.75" />
        <path d="M19 1.2v35.6" stroke="rgba(115,182,170,0.14)" strokeWidth="0.7" />
        <circle cx="19" cy="19" r="3.1" fill="#73B6AA" />
        <circle cx="19" cy="19" r="6" stroke="#73B6AA" strokeWidth="0.7" opacity="0.55" />
        <circle cx="28.6" cy="10.6" r="2" fill="#A9D1C5" />
        <circle cx="9.6" cy="26.4" r="1.4" fill="rgba(169,209,197,0.75)" />
      </svg>
      <span className="flex flex-col leading-none">
        <span className="flex items-baseline gap-[0.4rem]">
          <span
            className="font-sans text-[1.02rem] font-semibold uppercase tracking-[0.19em]"
            style={{ color: ink }}
          >
            DSC
          </span>
          <span
            className="font-sans text-[1.02rem] font-light uppercase tracking-[0.19em]"
            style={{ color: tone === "light" ? "#A9D1C5" : "#4F9287" }}
          >
            Drugs
          </span>
        </span>
        {showTagline && (
          <span
            className="mt-[0.4rem] font-sans text-[0.5rem] font-medium uppercase tracking-[0.3em]"
            style={{ color: muted }}
          >
            Pharmaceutical Trading
          </span>
        )}
      </span>
    </span>
  );

  if (!asLink) return content;
  return (
    <Link href="/" aria-label="DSC Drugs — home" className="inline-flex focus-visible:outline-offset-8">
      {content}
    </Link>
  );
}

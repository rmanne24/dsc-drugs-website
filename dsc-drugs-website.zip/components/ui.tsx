import Link from "next/link";
import type { ReactNode } from "react";
import { ArrowRight } from "@/components/Icons";
import { Reveal } from "@/components/Reveal";

export function SectionLabel({
  children,
  invert = false,
  className = "",
}: {
  children: ReactNode;
  invert?: boolean;
  className?: string;
}) {
  return (
    <span className={`eyebrow ${invert ? "eyebrow-invert" : ""} ${className}`}>{children}</span>
  );
}

type ButtonVariant = "jade" | "ink" | "outline-invert" | "outline" | "quiet";

export function LinkButton({
  href,
  children,
  variant = "jade",
  className = "",
  arrow = true,
  onClick,
  external,
  ariaLabel,
}: {
  href: string;
  children: ReactNode;
  variant?: ButtonVariant;
  className?: string;
  arrow?: boolean;
  onClick?: () => void;
  external?: boolean;
  ariaLabel?: string;
}) {
  const cls = `btn ${variant === "outline" ? "" : `btn-${variant}`} ${className}`;
  const inner = (
    <>
      <span>{children}</span>
      {arrow && <ArrowRight size={16} />}
    </>
  );

  if (external) {
    return (
      <a
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        className={cls}
        aria-label={ariaLabel}
        onClick={onClick}
      >
        {inner}
      </a>
    );
  }

  return (
    <Link href={href} className={cls} aria-label={ariaLabel} onClick={onClick}>
      {inner}
    </Link>
  );
}

export function SectionIntro({
  label,
  title,
  copy,
  invert = false,
  align = "left",
}: {
  label: string;
  title: ReactNode;
  copy?: ReactNode;
  invert?: boolean;
  align?: "left" | "center";
}) {
  return (
    <div className={align === "center" ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}>
      <Reveal>
        <SectionLabel invert={invert}>{label}</SectionLabel>
      </Reveal>
      <Reveal delay={90}>
        <h2 className="display-sm mt-6">{title}</h2>
      </Reveal>
      {copy && (
        <Reveal delay={170}>
          <p className={`lede mt-6 ${invert ? "text-ivory/65" : ""}`}>{copy}</p>
        </Reveal>
      )}
    </div>
  );
}

"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { ArrowRight, Close, Layers, Search, Trash } from "@/components/Icons";
import { ProductCard } from "@/components/ProductCard";
import { useEnquiry } from "@/components/EnquiryProvider";
import { categories, products } from "@/lib/products";

type Sort = "catalogue" | "az" | "category";

export function Catalogue({ initialCategory = "all" }: { initialCategory?: string }) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState(initialCategory);
  const [sort, setSort] = useState<Sort>("catalogue");
  const { items, remove, clear, count } = useEnquiry();

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    const filtered = products.filter((product) => {
      const inCategory = category === "all" || product.categorySlug === category;
      if (!inCategory) return false;
      if (!q) return true;
      return [product.name, product.summary, product.segment, product.category]
        .join(" ")
        .toLowerCase()
        .includes(q);
    });

    if (sort === "az") return [...filtered].sort((a, b) => a.name.localeCompare(b.name));
    if (sort === "category")
      return [...filtered].sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name));
    return filtered;
  }, [query, category, sort]);

  const activeFilters = (category !== "all" ? 1 : 0) + (query.trim() ? 1 : 0);

  return (
    <div>
      <div id="catalogue" className="scroll-mt-28">
        <div className="grid gap-6 border-y border-ink/12 py-6 lg:grid-cols-[1fr_auto] lg:items-end">
          <div className="relative max-w-md">
            <label htmlFor="catalogue-search" className="mono-label">
              Search the catalogue
            </label>
            <div className="relative mt-2.5">
              <Search size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-ink/35" />
              <input
                id="catalogue-search"
                type="search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Product, segment or category"
                className="w-full border border-ink/15 bg-paper py-3 pl-10 pr-10 text-sm text-ink outline-none transition-colors placeholder:text-ink/30 focus:border-jade-deep focus:ring-2 focus:ring-jade/20"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => setQuery("")}
                  aria-label="Clear search"
                  className="absolute right-2.5 top-1/2 flex h-7 w-7 -translate-y-1/2 items-center justify-center text-ink/40 transition-colors hover:text-ink"
                >
                  <Close size={14} />
                </button>
              )}
            </div>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:gap-6">
            <div>
              <label htmlFor="catalogue-sort" className="mono-label">
                Sort by
              </label>
              <select
                id="catalogue-sort"
                value={sort}
                onChange={(event) => setSort(event.target.value as Sort)}
                className="mt-2.5 block w-full appearance-none border border-ink/15 bg-paper py-3 pl-3.5 pr-9 text-[0.8rem] text-ink outline-none transition-colors focus:border-jade-deep sm:w-52"
              >
                <option value="catalogue">Catalogue order</option>
                <option value="az">Name A–Z</option>
                <option value="category">Category</option>
              </select>
            </div>
            <p className="mono-label pb-3 sm:pb-3.5">
              {results.length} record{results.length === 1 ? "" : "s"}
            </p>
          </div>
        </div>

        <div className="mt-6 flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setCategory("all")}
            aria-pressed={category === "all"}
            className={`border px-3.5 py-2 text-[0.62rem] font-semibold uppercase tracking-[0.13em] transition-colors ${
              category === "all"
                ? "border-ink bg-ink text-ivory"
                : "border-ink/15 bg-transparent text-ink/55 hover:border-ink/35 hover:text-ink"
            }`}
          >
            All categories
          </button>
          {categories.map((item) => (
            <button
              key={item.slug}
              type="button"
              onClick={() => setCategory(item.slug)}
              aria-pressed={category === item.slug}
              className={`border px-3.5 py-2 text-[0.62rem] font-semibold uppercase tracking-[0.13em] transition-colors ${
                category === item.slug
                  ? "border-ink bg-ink text-ivory"
                  : "border-ink/15 bg-transparent text-ink/55 hover:border-ink/35 hover:text-ink"
              }`}
            >
              {item.name}
            </button>
          ))}
          {activeFilters > 0 && (
            <button
              type="button"
              onClick={() => {
                setQuery("");
                setCategory("all");
              }}
              className="ml-1 inline-flex items-center gap-1.5 text-[0.62rem] uppercase tracking-[0.13em] text-ink/40 underline-offset-4 transition-colors hover:text-ink hover:underline"
            >
              Reset
            </button>
          )}
        </div>

        <div aria-live="polite" className="sr-only">
          {results.length} products match the current filters.
        </div>

        {results.length === 0 ? (
          <div className="mt-10 border border-dashed border-ink/20 bg-paper px-6 py-16 text-center">
            <p className="font-serif text-[1.5rem] text-ink">No records match that search.</p>
            <p className="mx-auto mt-3 max-w-[40ch] text-sm leading-relaxed text-grey">
              The catalogue is being built out. Try a different term, or send us the requirement directly
              and we will confirm what can be sourced.
            </p>
            <div className="mt-7 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <button
                type="button"
                onClick={() => {
                  setQuery("");
                  setCategory("all");
                }}
                className="btn btn-outline"
              >
                Reset filters
              </button>
              <Link href="/#enquiry-form" className="btn btn-jade">
                Send a requirement
                <ArrowRight size={15} />
              </Link>
            </div>
          </div>
        ) : (
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {results.map((product, index) => (
              <ProductCard key={product.slug} product={product} index={index} />
            ))}
          </div>
        )}

        <p className="mt-8 max-w-[62ch] text-[0.72rem] leading-relaxed text-ink/40">
          Catalogue records marked “Placeholder record” illustrate the template and are not real
          products. Replace <code className="bg-ink/5 px-1">lib/products.ts</code> with verified data
          before launch — no specification, approval or availability is implied.
        </p>
      </div>

      {/* ----------------------------------------------------- ENQUIRY LIST */}
      <section id="enquiry-list" className="mt-16 scroll-mt-28 border border-ink/12 bg-paper">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-ink/10 px-5 py-4 sm:px-6">
          <div className="flex items-center gap-3">
            <span className="text-jade-deep">
              <Layers size={17} />
            </span>
            <h2 className="font-serif text-[1.35rem] text-ink">
              Your enquiry list <span className="text-ink/35">({count})</span>
            </h2>
          </div>
          {count > 0 && (
            <button
              type="button"
              onClick={clear}
              className="text-[0.6rem] uppercase tracking-[0.14em] text-ink/40 transition-colors hover:text-ink"
            >
              Clear list
            </button>
          )}
        </div>

        {count === 0 ? (
          <p className="px-5 py-10 text-sm leading-relaxed text-grey sm:px-6">
            Nothing added yet. Use “Add to enquiry” on any product to build a combined enquiry, then send
            it from the contact form.
          </p>
        ) : (
          <>
            <ul className="divide-y divide-ink/10">
              {items.map((item) => (
                <li key={item.slug} className="flex items-center gap-4 px-5 py-3.5 sm:px-6">
                  <div className="min-w-0 flex-1">
                    <Link
                      href={`/products/${item.slug}`}
                      className="block truncate text-[0.9rem] font-medium text-ink transition-colors hover:text-jade-deep"
                    >
                      {item.name}
                    </Link>
                    <p className="mt-0.5 text-[0.6rem] uppercase tracking-[0.14em] text-ink/35">{item.category}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => remove(item.slug)}
                    aria-label={`Remove ${item.name}`}
                    className="flex h-9 w-9 items-center justify-center text-ink/35 transition-colors hover:text-[#a9604b]"
                  >
                    <Trash size={15} />
                  </button>
                </li>
              ))}
            </ul>
            <div className="flex flex-col gap-4 border-t border-ink/10 px-5 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6">
              <p className="text-[0.72rem] text-ink/45">
                Your list is kept in this browser and included in the enquiry form.
              </p>
              <Link href="/#enquiry-form" className="btn btn-jade">
                Send combined enquiry
                <ArrowRight size={15} />
              </Link>
            </div>
          </>
        )}
      </section>
    </div>
  );
}

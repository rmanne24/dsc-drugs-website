"use client";

import { useCallback, useMemo, useState } from "react";
import { Globe } from "@/components/Globe";
import { MapPin } from "@/components/Icons";
import type { Market } from "@/lib/markets";

export function GlobePanel({
  markets,
  compact = false,
  className = "",
}: {
  markets: Market[];
  compact?: boolean;
  className?: string;
}) {
  const [activeId, setActiveId] = useState<string | null>(markets[0]?.id ?? null);
  const active = useMemo(() => markets.find((m) => m.id === activeId) ?? null, [markets, activeId]);
  const onSelect = useCallback((id: string) => setActiveId(id), []);

  return (
    <div className={`grid items-center gap-8 ${compact ? "" : "lg:grid-cols-[1.15fr_0.85fr] lg:gap-14"} ${className}`}>
      <div className="relative">
        <div className="absolute inset-x-[8%] bottom-[6%] h-8 rounded-[50%] bg-black/40 blur-2xl" aria-hidden="true" />
        <Globe
          markers={markets}
          activeId={activeId}
          onSelect={onSelect}
          className="mx-auto aspect-square w-full max-w-[620px]"
        />
      </div>

      <div>
        <ul className="grid grid-cols-2 gap-x-4 border-t border-white/10 sm:grid-cols-3 lg:grid-cols-2">
          {markets.map((market, index) => {
            const isActive = market.id === activeId;
            return (
              <li key={market.id} className="border-b border-white/10">
                <button
                  type="button"
                  onClick={() => setActiveId(market.id)}
                  aria-pressed={isActive}
                  className={`group flex w-full items-center justify-between gap-2 py-3.5 text-left transition-colors duration-200 ${
                    isActive ? "text-mint" : "text-ivory/55 hover:text-ivory"
                  }`}
                >
                  <span className="flex items-center gap-2.5">
                    <span
                      className={`h-1.5 w-1.5 rounded-full transition-colors ${
                        isActive ? "bg-jade" : "bg-ivory/25 group-hover:bg-jade/60"
                      }`}
                    />
                    <span className="text-[0.72rem] font-medium uppercase tracking-[0.13em]">
                      {market.region}
                    </span>
                  </span>
                  <span className="font-serif text-xs text-ivory/25">{String(index + 1).padStart(2, "0")}</span>
                </button>
              </li>
            );
          })}
        </ul>

        <div className="mt-5 min-h-[5.5rem] border border-white/10 bg-white/[0.03] p-4" aria-live="polite">
          {active ? (
            <>
              <p className="flex items-center gap-2 text-[0.62rem] uppercase tracking-[0.16em] text-jade">
                <MapPin size={13} />
                {active.label} · {active.region}
              </p>
              <p className="mt-2 text-[0.78rem] leading-relaxed text-ivory/50">{active.note}</p>
              {active.illustrative && (
                <p className="mt-2 text-[0.58rem] uppercase tracking-[0.16em] text-ivory/25">
                  Illustrative placeholder — not a confirmed market
                </p>
              )}
            </>
          ) : (
            <p className="text-[0.8rem] text-ivory/45">Select a hub to preview the market panel.</p>
          )}
        </div>
      </div>
    </div>
  );
}

"use client";

import { useEffect, useRef, useState } from "react";
import landDots from "@/lib/geo/land-dots.json";

export type GlobeMarker = {
  id: string;
  label: string;
  region: string;
  coords: [number, number];
};

type GlobeProps = {
  markers?: GlobeMarker[];
  activeId?: string | null;
  onSelect?: (id: string) => void;
  className?: string;
  /** Rotation speed multiplier. 0 stops the globe. */
  speed?: number;
  ariaLabel?: string;
};

const DEG = Math.PI / 180;
const TILT = -0.34;

type Projected = { x: number; y: number; z: number; r: number };

function project(lat: number, lon: number, rotation: number, cx: number, cy: number, radius: number): Projected {
  const phi = lat * DEG;
  const theta = (lon + rotation) * DEG;
  const cosPhi = Math.cos(phi);
  let x = cosPhi * Math.sin(theta);
  let y = Math.sin(phi);
  let z = cosPhi * Math.cos(theta);

  // Rotate the whole globe around the horizontal axis for a natural tilt.
  const cosT = Math.cos(TILT);
  const sinT = Math.sin(TILT);
  const yT = y * cosT + z * sinT;
  const zT = z * cosT - y * sinT;
  y = yT;
  z = zT;

  return { x: cx + x * radius, y: cy - y * radius, z, r: 0 };
}

/** Deterministic pseudo-random for the star field, so SSR/CSR decks never flicker. */
function hash(n: number) {
  const s = Math.sin(n * 127.1) * 43758.5453;
  return s - Math.floor(s);
}

export function Globe({
  markers = [],
  activeId = null,
  onSelect,
  className = "",
  speed = 1,
  ariaLabel = "Rotating globe showing DSC Drugs market hubs",
}: GlobeProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const rotationRef = useRef(-20);
  const draggingRef = useRef(false);
  const velocityRef = useRef(0);
  const lastXRef = useRef(0);
  const markerHitsRef = useRef<{ id: string; x: number; y: number }[]>([]);
  const reducedRef = useRef(false);
  const [hovered, setHovered] = useState<string | null>(null);
  const hoveredRef = useRef<string | null>(null);
  const activeIdRef = useRef<string | null>(activeId);

  useEffect(() => {
    activeIdRef.current = activeId;
  }, [activeId]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    reducedRef.current = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    let width = 0;
    let height = 0;
    let dpr = 1;
    let frame = 0;
    let visible = true;
    let last = performance.now();

    const resize = () => {
      const rect = wrap.getBoundingClientRect();
      width = Math.max(rect.width, 1);
      height = Math.max(rect.height, 1);
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const draw = (now: number) => {
      const delta = Math.min(now - last, 48);
      last = now;
      if (!draggingRef.current && !reducedRef.current) {
        rotationRef.current += delta * 0.0055 * speed + velocityRef.current;
        velocityRef.current *= 0.94;
      }

      const cx = width / 2;
      const cy = height / 2;
      const radius = Math.min(width, height) * 0.395;
      const rotation = rotationRef.current;
      const compact = width < 520;
      const step = compact ? 2 : 1;
      const dotSize = Math.max(radius / 190, 0.85);

      ctx.clearRect(0, 0, width, height);

      // Atmosphere
      const halo = ctx.createRadialGradient(cx, cy, radius * 0.72, cx, cy, radius * 1.42);
      halo.addColorStop(0, "rgba(115,182,170,0.16)");
      halo.addColorStop(0.55, "rgba(115,182,170,0.05)");
      halo.addColorStop(1, "rgba(115,182,170,0)");
      ctx.fillStyle = halo;
      ctx.beginPath();
      ctx.arc(cx, cy, radius * 1.45, 0, Math.PI * 2);
      ctx.fill();

      // Ocean
      const ocean = ctx.createRadialGradient(cx - radius * 0.25, cy - radius * 0.3, radius * 0.1, cx, cy, radius);
      ocean.addColorStop(0, "rgba(26,64,64,0.9)");
      ocean.addColorStop(0.65, "rgba(12,36,38,0.92)");
      ocean.addColorStop(1, "rgba(7,22,23,0.96)");
      ctx.fillStyle = ocean;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.fill();

      // Land dots, bucketed by depth so each alpha level is a single fill.
      const buckets: Path2D[] = Array.from({ length: 6 }, () => new Path2D());
      const total = landDots.length;
      for (let i = 0; i < total; i += step) {
        const [lat, lon] = landDots[i];
        const p = project(lat, lon, rotation, cx, cy, radius);
        if (p.z <= 0.02) continue;
        const bucket = Math.min(5, Math.floor(p.z * 6));
        const s = dotSize * (0.72 + p.z * 0.7);
        buckets[bucket].rect(p.x - s / 2, p.y - s / 2, s, s);
      }
      for (let b = 0; b < buckets.length; b += 1) {
        ctx.fillStyle = `rgba(186,222,211,${0.11 + b * 0.085})`;
        ctx.fill(buckets[b]);
      }

      // Terminator shading for depth
      const shade = ctx.createRadialGradient(cx - radius * 0.45, cy - radius * 0.5, radius * 0.2, cx, cy, radius * 1.02);
      shade.addColorStop(0, "rgba(255,255,255,0.045)");
      shade.addColorStop(0.55, "rgba(255,255,255,0)");
      shade.addColorStop(1, "rgba(0,0,0,0.42)");
      ctx.fillStyle = shade;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.fill();

      // Rim
      ctx.strokeStyle = "rgba(169,209,197,0.24)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.stroke();

      // Markers
      const hits: { id: string; x: number; y: number }[] = [];
      for (const marker of markers) {
        const p = project(marker.coords[0], marker.coords[1], rotation, cx, cy, radius);
        if (p.z <= 0.05) continue;
        hits.push({ id: marker.id, x: p.x, y: p.y });
        const isActive = marker.id === activeIdRef.current || marker.id === hoveredRef.current;
        const size = isActive ? 4.4 : 3;
        const pulse = reducedRef.current ? 0 : (Math.sin(now / 620 + marker.coords[0]) + 1) / 2;
        const alpha = Math.min(1, p.z * 1.6);

        ctx.beginPath();
        ctx.arc(p.x, p.y, (isActive ? 15 : 10) + pulse * 5, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(115,182,170,${0.16 + pulse * 0.2 * alpha})`;
        ctx.lineWidth = 1;
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(p.x, p.y, size, 0, Math.PI * 2);
        ctx.fillStyle = isActive ? "#DDF0E8" : "rgba(169,209,197,0.92)";
        ctx.fill();

        if (isActive) {
          ctx.beginPath();
          ctx.arc(p.x, p.y, size + 4, 0, Math.PI * 2);
          ctx.strokeStyle = "rgba(221,240,232,0.55)";
          ctx.stroke();
        }
      }
      markerHitsRef.current = hits;

      // Sparse stars, drawn behind everything by compositing order is fine here
      if (!compact) {
        for (let i = 0; i < 26; i += 1) {
          const sx = hash(i + 1) * width;
          const sy = hash(i + 91) * height;
          const dist = Math.hypot((sx - cx) / radius, (sy - cy) / radius);
          if (dist < 1.15 && dist > 0.2) continue;
          ctx.fillStyle = `rgba(243,244,240,${0.06 + hash(i + 31) * 0.14})`;
          ctx.fillRect(sx, sy, 1.2, 1.2);
        }
      }
    };

    const loop = (now: number) => {
      if (!visible) {
        frame = requestAnimationFrame(loop);
        return;
      }
      draw(now);
      frame = requestAnimationFrame(loop);
    };

    resize();
    const observer = new ResizeObserver(() => {
      resize();
      draw(performance.now());
    });
    observer.observe(wrap);

    const io = new IntersectionObserver(
      (entries) => {
        visible = entries[0]?.isIntersecting ?? true;
        last = performance.now();
      },
      { threshold: 0 },
    );
    io.observe(wrap);

    if (reducedRef.current) {
      draw(performance.now());
    } else {
      frame = requestAnimationFrame(loop);
    }

    const onVisibility = () => {
      visible = !document.hidden;
      last = performance.now();
    };
    document.addEventListener("visibilitychange", onVisibility);

    const hitTest = (event: PointerEvent | MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      const px = event.clientX - rect.left;
      const py = event.clientY - rect.top;
      let best: string | null = null;
      let bestDist = 22;
      for (const hit of markerHitsRef.current) {
        const d = Math.hypot(hit.x - px, hit.y - py);
        if (d < bestDist) {
          bestDist = d;
          best = hit.id;
        }
      }
      return { best, px };
    };

    const onPointerDown = (event: PointerEvent) => {
      draggingRef.current = true;
      lastXRef.current = event.clientX;
      velocityRef.current = 0;
      canvas.setPointerCapture?.(event.pointerId);
      canvas.style.cursor = "grabbing";
    };

    const onPointerMove = (event: PointerEvent) => {
      if (draggingRef.current) {
        const dx = event.clientX - lastXRef.current;
        lastXRef.current = event.clientX;
        rotationRef.current += dx * 0.28;
        velocityRef.current = dx * 0.02;
        return;
      }
      const { best } = hitTest(event);
      if (best !== hoveredRef.current) {
        hoveredRef.current = best;
        setHovered(best);
      }
      canvas.style.cursor = best && onSelect ? "pointer" : "grab";
    };

    const onPointerUp = (event: PointerEvent) => {
      if (!draggingRef.current) return;
      draggingRef.current = false;
      canvas.style.cursor = "grab";
      const moved = Math.abs(event.clientX - lastXRef.current);
      if (!onSelect) return;
      const { best } = hitTest(event);
      if (best && moved < 6) onSelect(best);
    };

    canvas.style.cursor = "grab";
    canvas.addEventListener("pointerdown", onPointerDown);
    window.addEventListener("pointermove", onPointerMove);
    window.addEventListener("pointerup", onPointerUp);
    window.addEventListener("pointercancel", onPointerUp);

    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
      io.disconnect();
      document.removeEventListener("visibilitychange", onVisibility);
      canvas.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", onPointerUp);
      window.removeEventListener("pointercancel", onPointerUp);
    };
  }, [markers, onSelect, speed]);

  const hoveredMarker = markers.find((m) => m.id === hovered);

  return (
    <div ref={wrapRef} className={`relative ${className}`}>
      <canvas
        ref={canvasRef}
        className="block h-full w-full touch-pan-y select-none"
        role="img"
        aria-label={ariaLabel}
      />
      {hoveredMarker && (
        <div className="pointer-events-none absolute left-1/2 top-4 -translate-x-1/2 whitespace-nowrap border border-white/15 bg-ink/85 px-3 py-1.5 text-[0.62rem] uppercase tracking-[0.16em] text-mint backdrop-blur">
          {hoveredMarker.region}
        </div>
      )}
    </div>
  );
}

import type { ProductCategory } from "@/lib/products";

/**
 * Bespoke brand artwork, drawn in SVG so the visual identity stays
 * consistent and no unlicensed stock photography is used. Replace with
 * approved company photography by swapping these components for <Image>.
 */

function Grain({ id = "artGrain" }: { id?: string }) {
  return (
    <filter id={id} x="0" y="0" width="100%" height="100%">
      <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="3" stitchTiles="stitch" />
      <feColorMatrix type="saturate" values="0" />
    </filter>
  );
}

export function CategoryArt({ variant }: { variant: ProductCategory["art"] }) {
  if (variant === "molecule") {
    return (
      <svg viewBox="0 0 600 460" className="h-full w-full" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
        <defs>
          <linearGradient id="molBg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#EEF0EA" />
            <stop offset="1" stopColor="#DFE4DC" />
          </linearGradient>
          <radialGradient id="molGlow" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#A9D1C5" stopOpacity="0.75" />
            <stop offset="1" stopColor="#A9D1C5" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="molLine" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#0B2223" stopOpacity="0.38" />
            <stop offset="1" stopColor="#4F9287" stopOpacity="0.55" />
          </linearGradient>
        </defs>
        <rect width="600" height="460" fill="url(#molBg)" />
        <circle cx="440" cy="130" r="210" fill="url(#molGlow)" />
        <g stroke="url(#molLine)" strokeWidth="1" fill="none">
          <path d="M90 330 170 260 260 285 330 205 420 230 500 150" />
          <path d="M170 260 165 165 260 120 330 205" />
          <path d="M260 285 275 375 365 410 420 320 420 230" />
          <path d="M500 150 470 60 380 70 330 205" strokeDasharray="3 5" opacity="0.7" />
          <path d="M90 330 140 410 275 375" />
        </g>
        <g fill="#0B2223">
          {[
            [90, 330, 4],
            [170, 260, 5.5],
            [260, 285, 4],
            [330, 205, 6],
            [420, 230, 4],
            [500, 150, 5],
            [165, 165, 3.5],
            [260, 120, 5],
            [275, 375, 4],
            [365, 410, 3],
            [420, 320, 3.5],
            [470, 60, 3],
            [380, 70, 3.5],
            [140, 410, 3],
          ].map(([cx, cy, r], i) => (
            <circle key={i} cx={cx} cy={cy} r={r} fillOpacity={0.55 + (i % 3) * 0.12} />
          ))}
        </g>
        <g fill="#73B6AA">
          <circle cx="330" cy="205" r="2.2" />
          <circle cx="170" cy="260" r="2.2" />
          <circle cx="500" cy="150" r="2.2" />
        </g>
        <circle cx="440" cy="130" r="132" fill="none" stroke="#0B2223" strokeOpacity="0.1" />
        <circle cx="440" cy="130" r="168" fill="none" stroke="#0B2223" strokeOpacity="0.06" />
      </svg>
    );
  }

  if (variant === "vial") {
    return (
      <svg viewBox="0 0 600 460" className="h-full w-full" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
        <defs>
          <linearGradient id="vilBg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#0B2223" />
            <stop offset="0.55" stopColor="#123033" />
            <stop offset="1" stopColor="#07191A" />
          </linearGradient>
          <radialGradient id="vilGlow" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#73B6AA" stopOpacity="0.5" />
            <stop offset="1" stopColor="#73B6AA" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="vilBody" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#DCEFEA" stopOpacity="0.28" />
            <stop offset="0.5" stopColor="#A9D1C5" stopOpacity="0.1" />
            <stop offset="1" stopColor="#A9D1C5" stopOpacity="0.22" />
          </linearGradient>
          <linearGradient id="vilLiquid" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#73B6AA" stopOpacity="0.5" />
            <stop offset="1" stopColor="#4F9287" stopOpacity="0.85" />
          </linearGradient>
          <linearGradient id="vilSheen" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#FFFFFF" stopOpacity="0" />
            <stop offset="0.5" stopColor="#FFFFFF" stopOpacity="0.5" />
            <stop offset="1" stopColor="#FFFFFF" stopOpacity="0" />
          </linearGradient>
        </defs>
        <rect width="600" height="460" fill="url(#vilBg)" />
        <circle cx="330" cy="200" r="260" fill="url(#vilGlow)" />
        <g opacity="0.9">
          {/* vial one */}
          <g transform="translate(196 150)">
            <rect x="-5" y="0" width="74" height="14" rx="2" fill="#A9D1C5" fillOpacity="0.85" />
            <rect x="18" y="12" width="28" height="16" fill="#A9D1C5" fillOpacity="0.3" stroke="#A9D1C5" strokeOpacity="0.4" />
            <rect x="0" y="26" width="64" height="150" rx="26" fill="url(#vilBody)" stroke="#A9D1C5" strokeOpacity="0.45" />
            <rect x="6" y="96" width="52" height="74" rx="22" fill="url(#vilLiquid)" />
            <rect x="9" y="34" width="9" height="132" rx="5" fill="url(#vilSheen)" opacity="0.45" />
          </g>
          {/* vial two */}
          <g transform="translate(282 108)">
            <rect x="-5" y="0" width="78" height="15" rx="2" fill="#F3F4F0" fillOpacity="0.9" />
            <rect x="20" y="13" width="28" height="16" fill="#F3F4F0" fillOpacity="0.24" stroke="#F3F4F0" strokeOpacity="0.4" />
            <rect x="0" y="28" width="68" height="196" rx="27" fill="url(#vilBody)" stroke="#DCEFEA" strokeOpacity="0.5" />
            <rect x="6" y="120" width="56" height="98" rx="24" fill="url(#vilLiquid)" />
            <rect x="10" y="36" width="10" height="178" rx="5" fill="url(#vilSheen)" opacity="0.55" />
            <rect x="16" y="142" width="36" height="2" fill="#0B2223" opacity="0.25" />
            <rect x="16" y="152" width="26" height="2" fill="#0B2223" opacity="0.2" />
          </g>
          {/* vial three */}
          <g transform="translate(374 176)">
            <rect x="-5" y="0" width="66" height="13" rx="2" fill="#A9D1C5" fillOpacity="0.7" />
            <rect x="15" y="11" width="26" height="14" fill="#A9D1C5" fillOpacity="0.26" stroke="#A9D1C5" strokeOpacity="0.4" />
            <rect x="0" y="24" width="56" height="126" rx="23" fill="url(#vilBody)" stroke="#A9D1C5" strokeOpacity="0.35" />
            <rect x="5" y="82" width="46" height="62" rx="20" fill="url(#vilLiquid)" opacity="0.8" />
            <rect x="8" y="31" width="8" height="110" rx="4" fill="url(#vilSheen)" opacity="0.4" />
          </g>
        </g>
        <ellipse cx="300" cy="366" rx="172" ry="16" fill="#73B6AA" opacity="0.12" />
        <ellipse cx="300" cy="366" rx="96" ry="8" fill="#A9D1C5" opacity="0.1" />
        <path d="M0 400h600" stroke="#A9D1C5" strokeOpacity="0.14" />
      </svg>
    );
  }

  if (variant === "tablet") {
    return (
      <svg viewBox="0 0 600 460" className="h-full w-full" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
        <defs>
          <linearGradient id="tabBg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#F5F6F2" />
            <stop offset="1" stopColor="#E2E6DE" />
          </linearGradient>
          <radialGradient id="tabGlow" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#F9FBF7" stopOpacity="0.9" />
            <stop offset="1" stopColor="#F9FBF7" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="tabPill" x1="0" y1="0" x2="0.6" y2="1">
            <stop offset="0" stopColor="#D7E8E1" />
            <stop offset="0.55" stopColor="#A9D1C5" />
            <stop offset="1" stopColor="#7FBFB1" />
          </linearGradient>
          <linearGradient id="tabPill2" x1="0" y1="0" x2="0.6" y2="1">
            <stop offset="0" stopColor="#FBFCF8" />
            <stop offset="1" stopColor="#DDE4DA" />
          </linearGradient>
          <linearGradient id="tabPack" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#FFFFFF" stopOpacity="0.82" />
            <stop offset="1" stopColor="#FFFFFF" stopOpacity="0.32" />
          </linearGradient>
        </defs>
        <rect width="600" height="460" fill="url(#tabBg)" />
        <circle cx="180" cy="120" r="240" fill="url(#tabGlow)" />
        <g transform="rotate(-7 300 230)">
          <rect x="96" y="78" width="408" height="300" rx="12" fill="url(#tabPack)" stroke="#0B2223" strokeOpacity="0.13" />
          <rect x="112" y="94" width="376" height="268" rx="6" fill="none" stroke="#0B2223" strokeOpacity="0.07" strokeDasharray="2 6" />
          {[0, 1, 2].map((col) =>
            [0, 1].map((row) => {
              const x = 148 + col * 112;
              const y = 150 + row * 104;
              return (
                <g key={`${col}-${row}`}>
                  <rect x={x - 42} y={y - 38} width="84" height="76" rx="4" fill="#0B2223" fillOpacity="0.02" stroke="#0B2223" strokeOpacity="0.08" />
                  <ellipse cx={x} cy={y + 4} rx="31" ry="14" fill="#0B2223" opacity="0.07" />
                  <ellipse cx={x} cy={y} rx="30" ry="13" fill={(col + row) % 2 === 0 ? "url(#tabPill)" : "url(#tabPill2)"} stroke="#0B2223" strokeOpacity="0.12" />
                  <ellipse cx={x} cy={y - 2} rx="22" ry="8" fill="#FFFFFF" opacity={(col + row) % 2 === 0 ? 0.25 : 0.55} />
                  <path d={`M${x - 30} ${y + 1}h60`} stroke="#0B2223" strokeOpacity="0.16" transform={`rotate(-4 ${x} ${y})`} />
                </g>
              );
            }),
          )}
          <path d="M110 108v-8h-8M490 108v-8h8M110 354v8h-8M490 354v8h8" stroke="#0B2223" strokeOpacity="0.3" />
        </g>
        <circle cx="500" cy="392" r="3" fill="#4F9287" />
      </svg>
    );
  }

  return (
    <svg viewBox="0 0 600 460" className="h-full w-full" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      <defs>
        <linearGradient id="spcBg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#1B2B2D" />
          <stop offset="0.6" stopColor="#24282B" />
          <stop offset="1" stopColor="#0B2223" />
        </linearGradient>
        <radialGradient id="spcGlow" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#73B6AA" stopOpacity="0.34" />
          <stop offset="1" stopColor="#73B6AA" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="spcCapA" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#F3F4F0" />
          <stop offset="1" stopColor="#C9D8D1" />
        </linearGradient>
        <linearGradient id="spcCapB" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#8CC7BA" />
          <stop offset="1" stopColor="#3F7F75" />
        </linearGradient>
        <Grain />
      </defs>
      <rect width="600" height="460" fill="url(#spcBg)" />
      <circle cx="300" cy="230" r="280" fill="url(#spcGlow)" />
      <g fill="none" stroke="#A9D1C5" strokeOpacity="0.16">
        <circle cx="300" cy="230" r="88" />
        <circle cx="300" cy="230" r="132" strokeOpacity="0.1" />
        <circle cx="300" cy="230" r="186" strokeOpacity="0.07" />
        <path d="M300 44v372" strokeOpacity="0.05" />
        <path d="M44 230h512" strokeOpacity="0.05" />
      </g>
      <g transform="rotate(-32 300 230)">
        <rect x="150" y="196" width="300" height="70" rx="35" fill="#0B2223" opacity="0.3" transform="translate(0 10)" />
        <path d="M300 196h115a35 35 0 0 1 0 70H300z" fill="url(#spcCapA)" />
        <path d="M300 196H185a35 35 0 0 0 0 70h115z" fill="url(#spcCapB)" />
        <rect x="299" y="196" width="2" height="70" fill="#0B2223" opacity="0.18" />
        <rect x="196" y="212" width="80" height="10" rx="5" fill="#FFFFFF" opacity="0.22" />
        <circle cx="238" cy="231" r="13" fill="#0B2223" opacity="0.14" />
      </g>
      <g fill="#A9D1C5">
        <circle cx="118" cy="86" r="2" />
        <circle cx="486" cy="118" r="1.6" opacity="0.7" />
        <circle cx="500" cy="366" r="2.2" />
        <circle cx="146" cy="392" r="1.4" opacity="0.6" />
      </g>
      <path d="M96 348c38-10 58-38 74-72" stroke="#A9D1C5" strokeOpacity="0.18" strokeDasharray="2 5" fill="none" />
      <rect width="600" height="460" filter="url(#artGrain)" opacity="0.4" />
    </svg>
  );
}

export function AboutArt() {
  return (
    <svg viewBox="0 0 760 900" className="h-full w-full" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      <defs>
        <linearGradient id="abBg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#0B2223" />
          <stop offset="0.55" stopColor="#14383A" />
          <stop offset="1" stopColor="#07191A" />
        </linearGradient>
        <radialGradient id="abLight" cx="0.5" cy="0.2" r="0.75">
          <stop offset="0" stopColor="#A9D1C5" stopOpacity="0.5" />
          <stop offset="0.55" stopColor="#73B6AA" stopOpacity="0.14" />
          <stop offset="1" stopColor="#0B2223" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="abArch" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#F3F4F0" stopOpacity="0.16" />
          <stop offset="1" stopColor="#F3F4F0" stopOpacity="0.02" />
        </linearGradient>
        <linearGradient id="abArch2" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#A9D1C5" stopOpacity="0.3" />
          <stop offset="1" stopColor="#A9D1C5" stopOpacity="0.02" />
        </linearGradient>
        <Grain id="grainAbout" />
      </defs>
      <rect width="760" height="900" fill="url(#abBg)" />
      <rect width="760" height="900" fill="url(#abLight)" />
      <g stroke="#A9D1C5" strokeOpacity="0.08">
        <path d="M0 700h760" />
        <path d="M0 760h760" />
        <path d="M0 820h760" />
      </g>
      <g>
        <path d="M120 820V420c0-115 116-208 260-208s260 93 260 208v400Z" fill="url(#abArch)" stroke="#A9D1C5" strokeOpacity="0.28" />
        <path d="M188 840V470c0-83 86-150 192-150s192 67 192 150v370Z" fill="none" stroke="#A9D1C5" strokeOpacity="0.22" />
        <path d="M256 860V520c0-52 56-94 124-94s124 42 124 94v340Z" fill="url(#abArch2)" stroke="#A9D1C5" strokeOpacity="0.3" />
      </g>
      <g stroke="#A9D1C5" strokeOpacity="0.4" fill="none">
        <circle cx="380" cy="428" r="6" fill="#73B6AA" fillOpacity="0.9" stroke="none" />
        <circle cx="380" cy="428" r="18" />
        <circle cx="380" cy="428" r="40" strokeOpacity="0.2" />
        <path d="M380 446v110" strokeDasharray="2 6" />
        <path d="M330 502h100" strokeOpacity="0.2" />
      </g>
      <g transform="translate(560 690)" opacity="0.8">
        <path d="M0 0c50-32 84-80 96-140" stroke="#A9D1C5" strokeOpacity="0.35" fill="none" strokeDasharray="2 5" />
        <circle cx="96" cy="-140" r="3.5" fill="#A9D1C5" />
        <circle cx="0" cy="0" r="3" fill="#73B6AA" />
      </g>
      <text x="52" y="836" fill="#A9D1C5" fillOpacity="0.4" fontFamily="var(--font-sans)" fontSize="10" letterSpacing="4">
        TRADING · SOURCING · CONNECTIONS
      </text>
    </svg>
  );
}

export function PortraitArt({ index }: { index: string }) {
  return (
    <svg viewBox="0 0 520 650" className="h-full w-full" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      <defs>
        <linearGradient id={`ptBg${index}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#E7EAE2" />
          <stop offset="1" stopColor="#D8DED5" />
        </linearGradient>
        <radialGradient id={`ptGlow${index}`} cx="0.5" cy="0.3" r="0.7">
          <stop offset="0" stopColor="#FFFFFF" stopOpacity="0.85" />
          <stop offset="1" stopColor="#FFFFFF" stopOpacity="0" />
        </radialGradient>
        <linearGradient id={`ptShade${index}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0B2223" stopOpacity="0" />
          <stop offset="1" stopColor="#0B2223" stopOpacity="0.28" />
        </linearGradient>
        <Grain id={`grainPortrait${index}`} />
      </defs>
      <rect width="520" height="650" fill={`url(#ptBg${index})`} />
      <rect width="520" height="650" fill={`url(#ptGlow${index})`} />
      <g fill="none" stroke="#0B2223" strokeOpacity="0.12">
        <circle cx="260" cy="250" r="120" />
        <circle cx="260" cy="250" r="164" strokeOpacity="0.08" />
        <path d="M0 470h520" strokeOpacity="0.06" />
        <path d="M0 510h520" strokeOpacity="0.06" />
      </g>
      <g transform="translate(260 250)" opacity="0.5">
        <circle r="70" fill="#0B2223" fillOpacity="0.04" />
        <path d="M-34 34c8-30 22-44 34-44s26 14 34 44" stroke="#0B2223" strokeOpacity="0.16" fill="none" />
        <circle cy="-14" r="21" stroke="#0B2223" strokeOpacity="0.16" fill="none" />
      </g>
      <text
        x="38"
        y="566"
        fill="#0B2223"
        fillOpacity="0.13"
        fontFamily="var(--font-serif)"
        fontSize="150"
        fontWeight="300"
        letterSpacing="-6"
      >
        {index}
      </text>
      <rect y="520" width="520" height="130" fill={`url(#ptShade${index})`} />
      <text x="38" y="614" fill="#0B2223" fillOpacity="0.45" fontFamily="var(--font-sans)" fontSize="10" letterSpacing="3.4">
        PORTRAIT TO BE SUPPLIED
      </text>
    </svg>
  );
}

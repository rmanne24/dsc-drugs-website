"use client";

import { Check, Plus } from "@/components/Icons";
import { useEnquiry } from "@/components/EnquiryProvider";

export function EnquiryToggle({
  slug,
  name,
  category,
  variant = "card",
}: {
  slug: string;
  name: string;
  category: string;
  variant?: "card" | "inline";
}) {
  const { toggle, has, ready } = useEnquiry();
  const selected = has(slug);

  const label = selected ? "In enquiry list" : "Add to enquiry";

  return (
    <button
      type="button"
      onClick={(event) => {
        event.preventDefault();
        event.stopPropagation();
        toggle({ slug, name, category });
      }}
      aria-pressed={selected}
      aria-label={`${label}: ${name}`}
      disabled={!ready}
      className={
        variant === "card"
          ? `inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[0.58rem] font-semibold uppercase tracking-[0.12em] transition-colors duration-200 ${
              selected
                ? "border-jade/60 bg-jade/15 text-ink"
                : "border-ink/15 bg-white/60 text-ink/55 hover:border-ink/35 hover:text-ink"
            }`
          : `inline-flex items-center justify-center gap-2 border px-5 py-3 text-[0.7rem] font-semibold uppercase tracking-[0.13em] transition-colors duration-200 ${
              selected
                ? "border-jade bg-jade/10 text-ink"
                : "border-ink/20 text-ink hover:border-ink/50"
            }`
      }
    >
      {selected ? <Check size={13} /> : <Plus size={13} />}
      {label}
    </button>
  );
}

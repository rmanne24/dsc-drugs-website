import { ContactForm } from "@/components/ContactForm";
import { Clock, Mail, MapPin, Phone, WhatsAppIcon } from "@/components/Icons";
import { Reveal } from "@/components/Reveal";
import { SectionLabel } from "@/components/ui";
import { siteConfig, whatsappHref, whatsappMessages } from "@/lib/site";

type ContactDetail = {
  icon: typeof Mail;
  label: string;
  lines: readonly string[];
  href?: string;
  external?: boolean;
};

const details: ContactDetail[] = [
  {
    icon: MapPin,
    label: "Office address",
    lines: siteConfig.contact.addressLines,
  },
  {
    icon: Mail,
    label: "Email",
    lines: [siteConfig.contact.email],
    href: `mailto:${siteConfig.contact.email}`,
  },
  {
    icon: Phone,
    label: "Telephone",
    lines: [siteConfig.contact.phone],
    href: `tel:${siteConfig.contact.phoneHref}`,
  },
  {
    icon: WhatsAppIcon,
    label: "WhatsApp",
    lines: [siteConfig.whatsapp.displayNumber],
    href: whatsappHref(whatsappMessages.general),
    external: true,
  },
  {
    icon: Clock,
    label: "Business hours",
    lines: siteConfig.contact.hours,
  },
];

export function ContactSection({ id = "contact" }: { id?: string }) {
  return (
    <section id={id} className="section-dark section relative overflow-hidden" aria-labelledby="contact-heading">
      <div className="pointer-events-none absolute inset-0 grid-lines opacity-[0.35]" aria-hidden="true" />
      <div className="pointer-events-none absolute -right-24 top-10 h-[34rem] w-[34rem] rounded-full bg-jade/[0.07] blur-[120px]" aria-hidden="true" />

      <div className="shell relative grid gap-14 lg:grid-cols-[0.85fr_1.15fr] lg:gap-20">
        <div>
          <Reveal>
            <SectionLabel invert>Contact us</SectionLabel>
          </Reveal>
          <Reveal delay={80}>
            <h2 id="contact-heading" className="display-sm mt-6 text-ivory">
              Let&rsquo;s build a business <span className="serif-italic text-mint">connection.</span>
            </h2>
          </Reveal>
          <Reveal delay={150}>
            <p className="lede mt-6 max-w-[42ch] text-ivory/60">
              Whether you&rsquo;re looking for a product, exploring a partnership, or have a business
              enquiry, we&rsquo;d be glad to connect.
            </p>
          </Reveal>

          <div className="mt-11 space-y-0 border-t border-white/10">
            {details.map((detail, index) => (
              <Reveal key={detail.label} delay={200 + index * 60}>
                <div className="flex gap-4 border-b border-white/10 py-5">
                  <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-white/15 text-jade">
                    <detail.icon size={15} />
                  </span>
                  <div>
                    <p className="text-[0.6rem] font-semibold uppercase tracking-[0.18em] text-ivory/40">
                      {detail.label}
                    </p>
                    <div className="mt-1.5 space-y-0.5 text-[0.9rem] leading-relaxed text-ivory/75">
                      {detail.lines.map((line) =>
                        detail.href ? (
                          <a
                            key={line}
                            href={detail.href}
                            target={detail.external ? "_blank" : undefined}
                            rel={detail.external ? "noopener noreferrer" : undefined}
                            className="block break-all transition-colors hover:text-mint"
                          >
                            {line}
                          </a>
                        ) : (
                          <p key={line}>{line}</p>
                        ),
                      )}
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          {!siteConfig.contact.verified && (
            <p className="mt-5 text-[0.6rem] uppercase tracking-[0.16em] text-ivory/25">
              Placeholder contact details — to be confirmed before launch
            </p>
          )}
        </div>

        <Reveal delay={120} className="lg:pt-3">
          <div id="enquiry-form" className="scroll-mt-28">
            <ContactForm />
          </div>
        </Reveal>
      </div>
    </section>
  );
}

"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type EnquiryItem = {
  slug: string;
  name: string;
  category: string;
};

type EnquiryContextValue = {
  items: EnquiryItem[];
  count: number;
  ready: boolean;
  add: (item: EnquiryItem) => void;
  remove: (slug: string) => void;
  toggle: (item: EnquiryItem) => void;
  clear: () => void;
  has: (slug: string) => boolean;
};

const STORAGE_KEY = "dsc-enquiry-list-v1";
const EnquiryContext = createContext<EnquiryContextValue | null>(null);

export function EnquiryProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<EnquiryItem[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed: unknown = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          setItems(
            parsed
              .filter((entry): entry is EnquiryItem => Boolean(entry && typeof entry === "object" && "slug" in entry && "name" in entry))
              .slice(0, 20),
          );
        }
      }
    } catch {
      // Corrupted storage should never break the page.
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {
      // Private browsing may block storage; the list still works in memory.
    }
  }, [items, ready]);

  const add = useCallback((item: EnquiryItem) => {
    setItems((current) => (current.some((i) => i.slug === item.slug) ? current : [...current, item].slice(0, 20)));
  }, []);

  const remove = useCallback((slug: string) => {
    setItems((current) => current.filter((i) => i.slug !== slug));
  }, []);

  const toggle = useCallback((item: EnquiryItem) => {
    setItems((current) =>
      current.some((i) => i.slug === item.slug)
        ? current.filter((i) => i.slug !== item.slug)
        : [...current, item].slice(0, 20),
    );
  }, []);

  const clear = useCallback(() => setItems([]), []);

  const value = useMemo<EnquiryContextValue>(
    () => ({
      items,
      count: items.length,
      ready,
      add,
      remove,
      toggle,
      clear,
      has: (slug: string) => items.some((i) => i.slug === slug),
    }),
    [items, ready, add, remove, toggle, clear],
  );

  return <EnquiryContext.Provider value={value}>{children}</EnquiryContext.Provider>;
}

export function useEnquiry() {
  const context = useContext(EnquiryContext);
  if (!context) throw new Error("useEnquiry must be used inside EnquiryProvider");
  return context;
}

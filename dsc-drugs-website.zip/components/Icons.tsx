import type { ReactNode, SVGProps } from "react";

type IconProps = SVGProps<SVGSVGElement> & { size?: number };

function Icon({ size = 18, children, ...props }: IconProps & { children: ReactNode }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.3}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      {...props}
    >
      {children}
    </svg>
  );
}

export const ArrowRight = (p: IconProps) => (
  <Icon {...p}>
    <path d="M4 12h15" />
    <path d="m13 6 6 6-6 6" />
  </Icon>
);

export const ArrowUpRight = (p: IconProps) => (
  <Icon {...p}>
    <path d="M7 17 17 7" />
    <path d="M8 7h9v9" />
  </Icon>
);

export const ArrowUp = (p: IconProps) => (
  <Icon {...p}>
    <path d="M12 19V5" />
    <path d="m6 11 6-6 6 6" />
  </Icon>
);

export const ArrowDown = (p: IconProps) => (
  <Icon {...p}>
    <path d="M12 5v14" />
    <path d="m6 13 6 6 6-6" />
  </Icon>
);

export const Menu = (p: IconProps) => (
  <Icon {...p}>
    <path d="M3.5 9h17" />
    <path d="M3.5 15h17" />
  </Icon>
);

export const Close = (p: IconProps) => (
  <Icon {...p}>
    <path d="M6 6l12 12" />
    <path d="M18 6 6 18" />
  </Icon>
);

export const Search = (p: IconProps) => (
  <Icon {...p}>
    <circle cx="10.5" cy="10.5" r="6.5" />
    <path d="m15.5 15.5 4.5 4.5" />
  </Icon>
);

export const Check = (p: IconProps) => (
  <Icon {...p}>
    <path d="m4.5 12.5 5 5 10-11" />
  </Icon>
);

export const Plus = (p: IconProps) => (
  <Icon {...p}>
    <path d="M12 5v14" />
    <path d="M5 12h14" />
  </Icon>
);

export const Minus = (p: IconProps) => (
  <Icon {...p}>
    <path d="M5 12h14" />
  </Icon>
);

export const Trash = (p: IconProps) => (
  <Icon {...p}>
    <path d="M4 7h16" />
    <path d="M9 7V4.8c0-.4.4-.8.8-.8h4.4c.4 0 .8.4.8.8V7" />
    <path d="M6.5 7 7.4 19a1 1 0 0 0 1 .9h7.2a1 1 0 0 0 1-.9L17.5 7" />
  </Icon>
);

export const Mail = (p: IconProps) => (
  <Icon {...p}>
    <rect x="3" y="5.5" width="18" height="13" rx="1.5" />
    <path d="m3.8 6.5 8.2 6 8.2-6" />
  </Icon>
);

export const Phone = (p: IconProps) => (
  <Icon {...p}>
    <path d="M7.3 3.5H5.2c-.9 0-1.7.8-1.6 1.7.4 6.6 6.6 12.8 13.2 13.2.9.1 1.7-.7 1.7-1.6v-2.1c0-.7-.5-1.2-1.1-1.4l-2.4-.7c-.6-.2-1.2 0-1.6.5l-.8 1a13.6 13.6 0 0 1-5.3-5.3l1-.8c.5-.4.7-1 .5-1.6l-.7-2.4c-.2-.6-.7-1.1-1.4-1.1Z" />
  </Icon>
);

export const MapPin = (p: IconProps) => (
  <Icon {...p}>
    <path d="M12 21s7-6.1 7-11a7 7 0 1 0-14 0c0 4.9 7 11 7 11Z" />
    <circle cx="12" cy="10" r="2.4" />
  </Icon>
);

export const Clock = (p: IconProps) => (
  <Icon {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 7.5V12l3 1.8" />
  </Icon>
);

export const Document = (p: IconProps) => (
  <Icon {...p}>
    <path d="M6 2.8h7.5L19 8.3v12.9H6z" />
    <path d="M13.2 3v5.4H19" />
    <path d="M9 12.5h6" />
    <path d="M9 16h4" />
  </Icon>
);

export const Globe = (p: IconProps) => (
  <Icon {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <ellipse cx="12" cy="12" rx="3.8" ry="8.5" />
    <path d="M3.6 12h16.8" />
    <path d="M5 7.2h14" />
    <path d="M5 16.8h14" />
  </Icon>
);

export const Handshake = (p: IconProps) => (
  <Icon {...p}>
    <path d="M3 9.5 6.5 6l3 1.6h5L17.5 6 21 9.5" />
    <path d="M6.5 6v4.6L10 14l2-1.6 2 1.6 3.5-3.4V6" />
    <path d="M10 14v2.2l2 1.8 2-1.8V14" />
  </Icon>
);

export const Shield = (p: IconProps) => (
  <Icon {...p}>
    <path d="M12 2.8 4.8 5.5v6c0 4.4 3 8.1 7.2 9.7 4.2-1.6 7.2-5.3 7.2-9.7v-6z" />
    <path d="m8.8 12 2.3 2.3 4.2-4.6" />
  </Icon>
);

export const Layers = (p: IconProps) => (
  <Icon {...p}>
    <path d="m12 3 8.5 4.5L12 12 3.5 7.5z" />
    <path d="m4 12 8 4.3 8-4.3" />
    <path d="m4 16.5 8 4.3 8-4.3" />
  </Icon>
);

export const ChevronDown = (p: IconProps) => (
  <Icon {...p}>
    <path d="m6 9.5 6 6 6-6" />
  </Icon>
);

export const Linkedin = (p: IconProps) => (
  <Icon {...p}>
    <rect x="3" y="3" width="18" height="18" rx="2.2" />
    <path d="M7.2 10.2v7" />
    <circle cx="7.2" cy="7.1" r="0.9" fill="currentColor" stroke="none" />
    <path d="M11 17.2v-7" />
    <path d="M11 13.2c0-1.7 1.1-3 2.8-3s2.9 1.2 2.9 3v4" />
  </Icon>
);

export const WhatsAppIcon = ({ size = 20, ...props }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...props}>
    <path d="M12.04 2C6.6 2 2.2 6.4 2.2 11.84c0 1.74.46 3.43 1.32 4.93L2 22l5.36-1.4a9.82 9.82 0 0 0 4.67 1.18h.01c5.43 0 9.84-4.4 9.84-9.84C21.88 6.4 17.47 2 12.04 2Zm0 17.94c-1.48 0-2.93-.4-4.19-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.14 8.14 0 0 1-1.25-4.34c0-4.5 3.67-8.17 8.18-8.17 4.5 0 8.17 3.67 8.17 8.18 0 4.5-3.67 8.19-8.12 8.19Zm4.49-6.13c-.25-.13-1.46-.72-1.68-.8-.22-.08-.39-.13-.55.13-.16.24-.63.8-.77.96-.14.16-.28.18-.53.06a6.7 6.7 0 0 1-1.97-1.21 7.35 7.35 0 0 1-1.36-1.7c-.14-.24-.02-.37.1-.5.12-.12.25-.29.37-.43.13-.15.17-.25.25-.41.08-.17.04-.31-.02-.44-.06-.12-.55-1.32-.75-1.8-.2-.48-.4-.41-.55-.42h-.47c-.16 0-.42.06-.64.3-.22.25-.85.83-.85 2.02s.87 2.34.99 2.5c.12.17 1.7 2.6 4.12 3.65.58.25 1.03.4 1.38.51.58.19 1.11.16 1.53.1.46-.07 1.46-.6 1.67-1.17.2-.58.2-1.07.14-1.18-.06-.1-.22-.16-.47-.28Z" />
  </svg>
);

export const Quote = (p: IconProps) => (
  <Icon {...p}>
    <path d="M9.5 6.5C7 7.6 5.5 9.8 5.5 12.4V17h5v-5H8.2c.1-1.8 1-3 2.6-3.7z" />
    <path d="M18 6.5c-2.5 1.1-4 3.3-4 5.9V17h5v-5h-2.3c.1-1.8 1-3 2.6-3.7z" />
  </Icon>
);

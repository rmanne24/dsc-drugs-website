import Link from "next/link";
import { BackToTop } from "@/components/BackToTop";
import { Linkedin } from "@/components/Icons";
import { Logo } from "@/components/Logo";
import { footerNav, legalNav, siteConfig } from "@/lib/site";

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="relative overflow-hidden bg-ink-deep text-ivory/60">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-white/10" />
      <div className="pointer-events-none absolute -left-40 top-0 h-[30rem] w-[30rem] rounded-full bg-jade/[0.06] blur-[110px]" />

      <div className="shell relative">
        <div className="grid gap-12 py-16 md:grid-cols-12 md:gap-8 md:py-20">
          <div className="md:col-span-5 lg:col-span-4">
            <Logo tone="light" showTagline={false} />
            <p className="mt-6 max-w-[30ch] text-[0.9rem] leading-relaxed text-ivory/55">
              A pharmaceutical trading company connecting products, partners and markets — with
              sourcing handled through qualified trade relationships.
            </p>
            {siteConfig.social.linkedin ? (
              <a
                href={siteConfig.social.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-7 inline-flex h-10 w-10 items-center justify-center border border-white/15 text-ivory/60 transition-colors hover:border-jade/50 hover:text-mint"
                aria-label="DSC Drugs on LinkedIn"
              >
                <Linkedin size={16} />
              </a>
            ) : (
              <p className="mt-7 text-[0.62rem] uppercase tracking-[0.18em] text-ivory/30">
                Social channels pending verification
              </p>
            )}
          </div>

          <div className="md:col-span-4 lg:col-span-3 lg:col-start-6">
            <p className="text-[0.6rem] font-semibold uppercase tracking-[0.2em] text-mint/70">
              Explore
            </p>
            <ul className="mt-5 grid grid-cols-2 gap-x-6 gap-y-2.5 sm:grid-cols-2 md:grid-cols-1">
              {footerNav.map((item) => (
                <li key={item.href}>
                  <a
                    href={item.href}
                    className="inline-block py-1 text-[0.86rem] text-ivory/60 transition-colors hover:text-mint"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-3 lg:col-span-3 lg:col-start-10">
            <p className="text-[0.6rem] font-semibold uppercase tracking-[0.2em] text-mint/70">
              Enquiries
            </p>
            <ul className="mt-5 space-y-3 text-[0.86rem]">
              <li>
                <a
                  href={`mailto:${siteConfig.contact.email}`}
                  className="break-all text-ivory/70 transition-colors hover:text-mint"
                >
                  {siteConfig.contact.email}
                </a>
              </li>
              <li>
                <a
                  href={`tel:${siteConfig.contact.phoneHref}`}
                  className="text-ivory/70 transition-colors hover:text-mint"
                >
                  {siteConfig.contact.phone}
                </a>
              </li>
              <li className="text-ivory/45">
                {siteConfig.contact.addressLines.join(", ")}
              </li>
              <li className="text-ivory/45">{siteConfig.contact.hours.join(" · ")}</li>
            </ul>
            <p className="mt-5 text-[0.6rem] uppercase tracking-[0.16em] text-ivory/25">
              Contact details shown as placeholders until confirmed
            </p>
          </div>
        </div>

        <div className="flex flex-col gap-5 border-t border-white/10 py-6 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-[0.72rem] text-ivory/40">
            <span>
              © {year} {siteConfig.legalName}. All rights reserved.
            </span>
            {legalNav.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="transition-colors hover:text-mint"
              >
                {item.label}
              </Link>
            ))}
          </div>
          <div className="flex items-center justify-between gap-6 sm:justify-end">
            <span className="text-[0.6rem] uppercase tracking-[0.18em] text-ivory/25">
              Trading, not manufacturing
            </span>
            <BackToTop />
          </div>
        </div>
      </div>
    </footer>
  );
}

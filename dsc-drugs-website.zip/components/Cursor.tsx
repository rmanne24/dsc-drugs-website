"use client";

import { useEffect, useRef } from "react";

/** Anything that should make the ring grow. */
const INTERACTIVE = 'a, button, [role="button"], summary, label, canvas, [data-cursor="grow"]';
/** Areas painted dark, where the cursor has to switch to a light tone. */
const DARK_AREA = '.section-dark, footer, header, .bg-ink, .bg-ink-deep, [data-cursor="light"]';
/** Native caret stays visible here, so the custom pointer steps aside. */
const TEXT_FIELD = "input, textarea, select, [contenteditable='true']";

const TONE_LIGHT = "#f3f4f0";
const TONE_DARK = "#0b2223";

/**
 * Dot-and-ring pointer.
 * Only runs on devices with a fine pointer and when motion is not reduced —
 * touch screens and reduced-motion users keep the native cursor.
 */
export function Cursor() {
  const dotRef = useRef<HTMLDivElement | null>(null);
  const ringRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const root = document.documentElement;
    const dot = dotRef.current;
    const ring = ringRef.current;
    if (!dot || !ring) return;

    const fine = window.matchMedia("(pointer: fine)");
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)");

    let enabled = false;
    let frame = 0;
    let x = -200;
    let y = -200;
    let ringX = -200;
    let ringY = -200;
    let lastSample = 0;

    const placeRing = () => {
      ring.style.transform = `translate3d(${ringX}px, ${ringY}px, 0)`;
    };

    const tick = () => {
      ringX += (x - ringX) * 0.18;
      ringY += (y - ringY) * 0.18;
      placeRing();
      frame = requestAnimationFrame(tick);
    };

    const sampleTone = () => {
      if (x < 0 || y < 0) return;
      const under = document.elementFromPoint(x, y);
      const onDark = under instanceof Element && under.closest(DARK_AREA);
      root.style.setProperty("--cursor-tone", onDark ? TONE_LIGHT : TONE_DARK);
    };

    const scheduleTone = () => {
      const now = performance.now();
      if (now - lastSample < 90) return;
      lastSample = now;
      sampleTone();
    };

    const onPointerMove = (event: PointerEvent) => {
      x = event.clientX;
      y = event.clientY;
      // The dot is pinned immediately; only the ring eases behind it.
      dot.style.transform = `translate3d(${x}px, ${y}px, 0)`;

      if (!dot.classList.contains("is-visible")) {
        ringX = x;
        ringY = y;
        placeRing();
        dot.classList.add("is-visible");
        ring.classList.add("is-visible");
        sampleTone();
      }

      const target = event.target instanceof Element ? event.target : null;
      const inTextField = Boolean(target?.closest(TEXT_FIELD));
      const interactive = Boolean(target?.closest(INTERACTIVE));

      dot.classList.toggle("is-hidden", inTextField);
      ring.classList.toggle("is-hidden", inTextField);
      ring.classList.toggle("is-active", interactive && !inTextField);

      scheduleTone();
    };

    const hide = () => {
      dot.classList.remove("is-visible");
      ring.classList.remove("is-visible");
      ring.classList.remove("is-active");
    };

    const start = () => {
      if (enabled) return;
      enabled = true;
      root.classList.add("cursor-custom");
      frame = requestAnimationFrame(tick);
      window.addEventListener("pointermove", onPointerMove, { passive: true });
      window.addEventListener("scroll", scheduleTone, { passive: true });
      window.addEventListener("blur", hide);
      document.addEventListener("pointerleave", hide);
    };

    const stop = () => {
      if (!enabled) return;
      enabled = false;
      root.classList.remove("cursor-custom");
      root.style.removeProperty("--cursor-tone");
      cancelAnimationFrame(frame);
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("scroll", scheduleTone);
      window.removeEventListener("blur", hide);
      document.removeEventListener("pointerleave", hide);
      dot.classList.remove("is-visible", "is-hidden");
      ring.classList.remove("is-visible", "is-hidden", "is-active");
      dot.style.transform = "";
      ring.style.transform = "";
    };

    const sync = () => {
      if (fine.matches && !reduce.matches) start();
      else stop();
    };

    sync();
    fine.addEventListener("change", sync);
    reduce.addEventListener("change", sync);

    return () => {
      stop();
      fine.removeEventListener("change", sync);
      reduce.removeEventListener("change", sync);
    };
  }, []);

  return (
    <div aria-hidden="true" className="pointer-events-none">
      <div ref={dotRef} className="cursor-dot">
        <span className="cursor-dot__inner" />
      </div>
      <div ref={ringRef} className="cursor-ring">
        <span className="cursor-ring__inner" />
      </div>
    </div>
  );
}

"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { products } from "@/lib/products";
import { siteConfig, whatsappHref, whatsappMessages } from "@/lib/site";
import { WhatsAppIcon } from "@/components/Icons";

/**
 * Floating WhatsApp entry point.
 * The message adapts to the current page: on a product detail page the
 * product name is pre-filled so the visitor only has to review and send.
 * The number lives in `lib/site.ts` and is never invented here.
 */
export function WhatsAppButton() {
  const pathname = usePathname();
  const productSlug = pathname.startsWith("/products/") ? pathname.split("/")[2] : null;
  const product = productSlug ? products.find((p) => p.slug === productSlug) : null;
  const message = product ? whatsappMessages.product(product.name) : whatsappMessages.general;
  const href = whatsappHref(message);

  const base =
    "group fixed bottom-4 right-4 z-40 flex h-14 items-center overflow-hidden rounded-full shadow-[0_16px_36px_-14px_rgba(11,34,35,0.6)] transition-[background-color,border-color,box-shadow] duration-300 sm:bottom-5 sm:right-6";

  if (!href) {
    return (
      <Link
        href="/#enquiry-form"
        aria-label={`WhatsApp is not connected yet — send an enquiry instead. ${siteConfig.whatsapp.verified ? "" : "WhatsApp number pending confirmation."}`}
        title="WhatsApp number pending confirmation — use the enquiry form"
        className={`${base} w-14 justify-start border border-white/15 bg-[#1f3d34] text-ivory hover:w-[15.5rem] focus-visible:w-[15.5rem] hover:bg-[#274a3f]`}
      >
        <span className="flex h-14 w-14 shrink-0 items-center justify-center text-[#a9d1c5]">
          <WhatsAppIcon size={25} />
        </span>
        <span className="flex min-w-0 flex-col pr-5 text-left leading-tight">
          <span className="whitespace-nowrap text-[0.72rem] font-semibold text-ivory">
            WhatsApp not connected
          </span>
          <span className="whitespace-nowrap text-[0.62rem] text-ivory/60">Send an enquiry instead</span>
        </span>
      </Link>
    );
  }

  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with us on WhatsApp"
      className={`${base} w-14 justify-start border border-[#2f5c4c] bg-[#1f3d34] text-ivory hover:w-[15.5rem] focus-visible:w-[15.5rem] hover:bg-[#255045]`}
    >
      <span className="flex h-14 w-14 shrink-0 items-center justify-center text-[#a9d1c5]">
        <WhatsAppIcon size={25} />
      </span>
      <span className="whitespace-nowrap pr-5 text-[0.72rem] font-semibold tracking-[0.01em]">
        Chat with us on WhatsApp
      </span>
    </a>
  );
}

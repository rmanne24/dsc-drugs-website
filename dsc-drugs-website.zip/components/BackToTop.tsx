"use client";

import { useEffect, useState } from "react";
import { ArrowUp } from "@/components/Icons";

export function BackToTop() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 800);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const scrollTop = () => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    window.scrollTo({ top: 0, behavior: reduce ? "auto" : "smooth" });
    document.getElementById("main")?.focus({ preventScroll: true });
  };

  return (
    <button
      type="button"
      onClick={scrollTop}
      aria-label="Back to top"
      tabIndex={visible ? 0 : -1}
      className={`group inline-flex items-center gap-2.5 border border-white/15 px-3.5 py-2.5 text-[0.6rem] font-semibold uppercase tracking-[0.16em] text-ivory/60 transition-all duration-300 hover:border-jade/50 hover:text-mint ${
        visible ? "opacity-100" : "pointer-events-none opacity-0"
      }`}
    >
      <ArrowUp size={14} className="transition-transform duration-300 group-hover:-translate-y-0.5" />
      Top
    </button>
  );
}

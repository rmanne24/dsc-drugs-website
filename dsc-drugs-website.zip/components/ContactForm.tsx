"use client";

import { useEffect, useId, useRef, useState } from "react";
import { ArrowRight, Check, Layers, Mail } from "@/components/Icons";
import { useEnquiry } from "@/components/EnquiryProvider";
import { products } from "@/lib/products";
import { enquiryTypes, siteConfig } from "@/lib/site";

type Errors = Partial<Record<"name" | "email" | "message" | "type", string>>;
type Status = "idle" | "submitting" | "delivered" | "development" | "error";

const initial = {
  name: "",
  email: "",
  company: "",
  country: "",
  type: "",
  product: "",
  message: "",
  website: "",
};

export function ContactForm() {
  const { items, clear } = useEnquiry();
  const [values, setValues] = useState(initial);
  const [errors, setErrors] = useState<Errors>({});
  const [status, setStatus] = useState<Status>("idle");
  const [serverError, setServerError] = useState<string | null>(null);
  const [reference, setReference] = useState<string | null>(null);
  const formRef = useRef<HTMLFormElement | null>(null);
  const uid = useId();

  useEffect(() => {
    if (values.product || items.length === 0) return;
    setValues((current) => ({ ...current, product: items.map((item) => item.name).join(", ") }));
  }, [items, values.product]);

  const update = (key: keyof typeof initial) => (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const value = event.target.value;
    setValues((current) => ({ ...current, [key]: value }));
    if (key in errors) setErrors((current) => ({ ...current, [key]: undefined }));
    if (status === "error") setStatus("idle");
  };

  const validate = () => {
    const next: Errors = {};
    if (values.name.trim().length < 2) next.name = "Please share your full name.";
    if (!values.email.trim()) next.email = "An email address is required so we can reply.";
    else if (!/^[^\s@<>()[\]\\,;:]+@[^\s@<>()[\]\\,;:]+\.[a-zA-Z]{2,}$/.test(values.email.trim()))
      next.email = "Please check the email address format.";
    if (values.message.trim().length < 20) next.message = "Please add a little more detail (at least 20 characters).";
    if (values.type && !(enquiryTypes as readonly string[]).includes(values.type))
      next.type = "Please choose one of the listed enquiry types.";
    return next;
  };

  const onSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (status === "submitting") return;

    const nextErrors = validate();
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) {
      setServerError(null);
      const firstKey = Object.keys(nextErrors)[0];
      const target = formRef.current?.querySelector<HTMLElement>(`[name="${firstKey}"]`);
      target?.focus();
      return;
    }

    setStatus("submitting");
    setServerError(null);

    try {
      const response = await fetch("/api/enquiry", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(values),
      });
      const result: {
        ok?: boolean;
        delivery?: "delivered" | "development" | "accepted";
        errors?: Errors;
        error?: string;
      } = await response.json().catch(() => ({}));

      if (!response.ok || !result.ok) {
        if (result.errors) setErrors(result.errors);
        setServerError(result.error ?? "Your enquiry could not be sent. Please try again in a moment.");
        setStatus("error");
        return;
      }

      setReference(`DSC-${Date.now().toString(36).toUpperCase().slice(-6)}`);
      setStatus(result.delivery === "delivered" ? "delivered" : "development");
      setValues(initial);
      clear();
    } catch {
      setServerError("We could not reach the server. Please check your connection or email us directly.");
      setStatus("error");
    }
  };

  const busy = status === "submitting";
  const done = status === "delivered" || status === "development";

  if (done) {
    return (
      <div className="flex h-full flex-col justify-center border border-white/12 bg-white/[0.03] p-7 sm:p-10">
        <span className="flex h-12 w-12 items-center justify-center rounded-full border border-jade/50 text-jade">
          <Check size={22} />
        </span>
        <h3 className="heading-serif mt-6 text-ivory">Thank you — your enquiry has been received.</h3>
        {status === "delivered" ? (
          <p className="mt-4 max-w-[42ch] text-sm leading-relaxed text-ivory/60">
            A member of the DSC Drugs team will review your message and respond to the email address you
            provided. For anything urgent, reach us directly at{" "}
            <a href={`mailto:${siteConfig.contact.email}`} className="text-mint underline-offset-4 hover:underline">
              {siteConfig.contact.email}
            </a>
            .
          </p>
        ) : (
          <div className="mt-4 max-w-[46ch] space-y-3 text-sm leading-relaxed text-ivory/60">
            <p className="border-l border-[#e0b98a]/60 pl-4 text-ivory/75">
              <strong className="font-semibold text-[#ecd3b4]">Development mode.</strong> Your enquiry was
              validated successfully, but no email has been sent yet — this build has no email provider
              connected. Please contact us directly using the details on the left until delivery is
              configured.
            </p>
            <p className="text-[0.72rem] uppercase tracking-[0.14em] text-ivory/35">
              To enable delivery, set RESEND_API_KEY and ENQUIRY_TO_EMAIL (or ENQUIRY_WEBHOOK_URL) on the server.
            </p>
          </div>
        )}
        {reference && (
          <p className="mono-label mt-6 text-ivory/40">Reference {reference}</p>
        )}
        <button
          type="button"
          onClick={() => {
            setStatus("idle");
            setReference(null);
          }}
          className="btn btn-outline-invert mt-8 self-start"
        >
          Send another enquiry
        </button>
      </div>
    );
  }

  return (
    <form
      ref={formRef}
      onSubmit={onSubmit}
      noValidate
      className="border border-white/12 bg-white/[0.025] p-6 sm:p-8 lg:p-9"
      aria-describedby={`${uid}-note`}
    >
      <div className="flex items-baseline justify-between gap-4">
        <p className="mono-label text-mint/70">Enquiry form</p>
        <p className="text-[0.6rem] uppercase tracking-[0.14em] text-ivory/30">Fields marked * are required</p>
      </div>

      <div className="mt-6 grid gap-5 sm:grid-cols-2">
        <Field label="Full Name" name="name" required error={errors.name} className="sm:col-span-1">
          <input
            className="input"
            id="cf-name"
            name="name"
            autoComplete="name"
            value={values.name}
            onChange={update("name")}
            aria-invalid={Boolean(errors.name)}
            aria-describedby={errors.name ? "cf-name-error" : undefined}
            placeholder="Your full name"
          />
        </Field>

        <Field label="Business Email" name="email" required error={errors.email}>
          <input
            className="input"
            id="cf-email"
            name="email"
            type="email"
            inputMode="email"
            autoComplete="email"
            value={values.email}
            onChange={update("email")}
            aria-invalid={Boolean(errors.email)}
            aria-describedby={errors.email ? "cf-email-error" : undefined}
            placeholder="name@company.com"
          />
        </Field>

        <Field label="Company Name" name="company">
          <input
            className="input"
            id="cf-company"
            name="company"
            autoComplete="organization"
            value={values.company}
            onChange={update("company")}
            placeholder="Company or institution"
          />
        </Field>

        <Field label="Country" name="country">
          <input
            className="input"
            id="cf-country"
            name="country"
            autoComplete="country-name"
            value={values.country}
            onChange={update("country")}
            placeholder="Country of operation"
          />
        </Field>

        <Field label="Enquiry Type" name="type" error={errors.type}>
          <select
            className="input"
            id="cf-type"
            name="type"
            value={values.type}
            onChange={update("type")}
            aria-invalid={Boolean(errors.type)}
            aria-describedby={errors.type ? "cf-type-error" : undefined}
          >
            <option value="">Select an enquiry type</option>
            {enquiryTypes.map((type) => (
              <option key={type} value={type}>
                {type}
              </option>
            ))}
          </select>
        </Field>

        <Field label="Product of Interest" name="product" optional>
          <input
            className="input"
            id="cf-product"
            name="product"
            list="enquiry-products"
            value={values.product}
            onChange={update("product")}
            placeholder="Product or category"
          />
          <datalist id="enquiry-products">
            {products.map((product) => (
              <option key={product.slug} value={product.name} />
            ))}
          </datalist>
        </Field>

        <Field label="Message" name="message" required error={errors.message} className="sm:col-span-2">
          <textarea
            className="input"
            id="cf-message"
            name="message"
            rows={5}
            value={values.message}
            onChange={update("message")}
            aria-invalid={Boolean(errors.message)}
            aria-describedby={errors.message ? "cf-message-error" : `${uid}-note`}
            placeholder="Tell us what you are looking for — product, quantity, destination market or partnership scope."
          />
        </Field>
      </div>

      {items.length > 0 && (
        <p className="mt-4 flex items-start gap-2 text-[0.72rem] leading-relaxed text-ivory/45">
          <Layers size={14} className="mt-0.5 shrink-0 text-jade" />
          {items.length} product{items.length > 1 ? "s" : ""} from your enquiry list{" "}
          {values.product.includes(items[0].name) ? "are included above." : "can be included in this message."}
        </p>
      )}

      {/* Honeypot: hidden from humans, visible to naive bots */}
      <div className="absolute -left-[9999px] top-auto h-px w-px overflow-hidden" aria-hidden="true">
        <label htmlFor="cf-website">Website</label>
        <input
          id="cf-website"
          name="website"
          tabIndex={-1}
          autoComplete="off"
          value={values.website}
          onChange={update("website")}
        />
      </div>

      {serverError && (
        <p role="alert" className="mt-5 border-l-2 border-[#e6a795] bg-[#e6a795]/10 px-4 py-3 text-[0.8rem] leading-relaxed text-[#f0c6b8]">
          {serverError}{" "}
          <a href={`mailto:${siteConfig.contact.email}`} className="underline underline-offset-2">
            Email us instead
          </a>
          .
        </p>
      )}

      <div className="mt-7 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <button type="submit" className="btn btn-jade w-full sm:w-auto" disabled={busy} aria-busy={busy}>
          {busy ? (
            <>
              <span className="h-3.5 w-3.5 animate-spin rounded-full border border-ink/30 border-t-ink" />
              Sending…
            </>
          ) : (
            <>
              Send Enquiry
              <ArrowRight size={16} />
            </>
          )}
        </button>
        <p id={`${uid}-note`} className="flex items-start gap-2 text-[0.68rem] leading-relaxed text-ivory/35">
          <Mail size={13} className="mt-0.5 shrink-0" />
          We use your details only to respond to this enquiry.
        </p>
      </div>
    </form>
  );
}

function Field({
  label,
  name,
  required,
  optional,
  error,
  className = "",
  children,
}: {
  label: string;
  name: string;
  required?: boolean;
  optional?: boolean;
  error?: string;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <div className={`field ${className}`}>
      <label className="field-label" htmlFor={`cf-${name}`}>
        {label} {required && <span className="req">*</span>}
        {optional && <span className="ml-1 normal-case tracking-normal text-ivory/30">(optional)</span>}
      </label>
      {children}
      {error && (
        <p id={`cf-${name}-error`} className="field-error">
          {error}
        </p>
      )}
    </div>
  );
}

"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { ArrowRight, Close, Layers, Plus, Trash } from "@/components/Icons";
import { useEnquiry } from "@/components/EnquiryProvider";

export function EnquiryDock() {
  const { items, count, remove, clear } = useEnquiry();
  const [open, setOpen] = useState(false);
  const panelRef = useRef<HTMLDivElement | null>(null);
  const triggerRef = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setOpen(false);
        triggerRef.current?.focus();
      }
    };
    document.addEventListener("keydown", onKey);
    const timer = window.setTimeout(
      () => panelRef.current?.querySelector<HTMLElement>("button, a")?.focus(),
      80,
    );
    return () => {
      document.removeEventListener("keydown", onKey);
      window.clearTimeout(timer);
    };
  }, [open]);

  return (
    <>
      <div
        className={`fixed bottom-[6.4rem] right-4 z-40 transition-all duration-300 sm:right-6 ${
          count > 0 || open ? "pointer-events-auto translate-y-0 opacity-100" : "pointer-events-none translate-y-2 opacity-0"
        }`}
      >
        <button
          ref={triggerRef}
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-controls="enquiry-drawer"
          className="group flex h-[52px] items-center gap-3 rounded-full border border-ink/10 bg-ivory/95 pl-4 pr-2 text-ink shadow-[0_18px_40px_-18px_rgba(11,34,35,0.5)] backdrop-blur transition-colors hover:border-jade"
        >
          <span className="flex items-center gap-2.5">
            <span className="relative text-ink/70">
              <Layers size={17} />
              <span className="absolute -right-2 -top-2 flex h-4 min-w-4 items-center justify-center rounded-full bg-ink px-1 text-[0.55rem] font-semibold leading-none text-mint">
                {count}
              </span>
            </span>
            <span className="hidden text-[0.62rem] font-semibold uppercase tracking-[0.16em] sm:block">
              Enquiry list
            </span>
          </span>
          <span className="flex h-9 items-center gap-1.5 rounded-full bg-jade/15 px-3 text-[0.62rem] font-semibold uppercase tracking-[0.12em] text-ink">
            View
            <ArrowRight size={13} />
          </span>
        </button>
      </div>

      <div
        className={`fixed inset-0 z-[80] transition-[visibility] duration-500 ${
          open ? "visible" : "invisible"
        }`}
        aria-hidden={!open}
      >
        <button
          type="button"
          tabIndex={-1}
          aria-label="Close enquiry list"
          onClick={() => setOpen(false)}
          className={`absolute inset-0 bg-ink/50 backdrop-blur-[2px] transition-opacity duration-500 ${
            open ? "opacity-100" : "opacity-0"
          }`}
        />
        <div
          id="enquiry-drawer"
          ref={panelRef}
          role="dialog"
          aria-modal="true"
          aria-label="Your enquiry list"
          className={`absolute bottom-0 right-0 top-0 flex w-full max-w-[420px] flex-col bg-ink text-ivory shadow-2xl transition-transform duration-500 ${
            open ? "translate-x-0" : "translate-x-full"
          }`}
          style={{ transitionTimingFunction: "cubic-bezier(0.22,0.61,0.36,1)" }}
        >
          <div className="flex items-start justify-between gap-4 border-b border-white/10 px-7 py-7">
            <div>
              <p className="mono-label text-mint/70">Multi-product enquiry</p>
              <h2 className="heading-serif mt-2 text-ivory">
                Enquiry list <span className="text-jade">({count})</span>
              </h2>
            </div>
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Close enquiry list"
              className="flex h-10 w-10 items-center justify-center border border-white/15 text-ivory/70 transition-colors hover:border-jade/60 hover:text-mint"
            >
              <Close size={18} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto px-7 py-6">
            {count === 0 ? (
              <div className="flex h-full flex-col items-start justify-center gap-5 pb-16">
                <span className="flex h-14 w-14 items-center justify-center rounded-full border border-white/15 text-jade">
                  <Layers size={22} />
                </span>
                <p className="text-sm leading-relaxed text-ivory/60">
                  Your enquiry list is empty. Add products from the catalogue to send one combined
                  enquiry.
                </p>
                <Link
                  href="/#catalogue"
                  onClick={() => setOpen(false)}
                  className="link-underline text-jade"
                >
                  Browse products
                </Link>
              </div>
            ) : (
              <ul className="divide-y divide-white/10">
                {items.map((item, index) => (
                  <li key={item.slug} className="flex items-start gap-4 py-4">
                    <span className="mt-0.5 font-serif text-lg text-jade/60">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    <div className="min-w-0 flex-1">
                      <Link
                        href={`/products/${item.slug}`}
                        onClick={() => setOpen(false)}
                        className="block truncate text-sm font-medium text-ivory transition-colors hover:text-mint"
                      >
                        {item.name}
                      </Link>
                      <p className="mt-0.5 text-[0.7rem] uppercase tracking-[0.12em] text-ivory/40">
                        {item.category}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => remove(item.slug)}
                      aria-label={`Remove ${item.name} from enquiry list`}
                      className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center text-ivory/40 transition-colors hover:text-[#e6a795]"
                    >
                      <Trash size={15} />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="border-t border-white/10 px-7 py-6">
            <Link
              href="/#enquiry-form"
              onClick={() => setOpen(false)}
              className="btn btn-jade w-full"
            >
              Send combined enquiry
              <ArrowRight size={15} />
            </Link>
            <div className="mt-4 flex items-center justify-between text-[0.7rem] text-ivory/45">
              <Link
                href="/#catalogue"
                onClick={() => setOpen(false)}
                className="inline-flex items-center gap-1.5 transition-colors hover:text-mint"
              >
                <Plus size={13} /> Add more products
              </Link>
              {count > 0 && (
                <button type="button" onClick={clear} className="transition-colors hover:text-[#e6a795]">
                  Clear list
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

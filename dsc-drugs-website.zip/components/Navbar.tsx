"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronDown, Close, Menu } from "@/components/Icons";
import { Logo } from "@/components/Logo";
import { primaryNav, siteConfig } from "@/lib/site";

export function Navbar() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [activeHash, setActiveHash] = useState("");
  const menuRef = useRef<HTMLDivElement | null>(null);
  const triggerRef = useRef<HTMLButtonElement | null>(null);
  const dropdownRef = useRef<HTMLLIElement | null>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  /* The whole site lives on one page, so the nav highlights whichever
     section the reader is currently inside. */
  useEffect(() => {
    if (pathname !== "/") {
      setActiveHash("");
      return;
    }
    const sections = ["about", "products", "global-presence", "management", "quality", "contact"]
      .map((id) => document.getElementById(id))
      .filter((el): el is HTMLElement => Boolean(el));
    if (sections.length === 0) return;

    const update = () => {
      const line = window.scrollY + 170;
      let current = "";
      for (const section of sections) {
        if (section.getBoundingClientRect().top + window.scrollY <= line) current = section.id;
      }
      setActiveHash(current);
    };
    update();
    window.addEventListener("scroll", update, { passive: true });
    window.addEventListener("resize", update);
    return () => {
      window.removeEventListener("scroll", update);
      window.removeEventListener("resize", update);
    };
  }, [pathname]);

  useEffect(() => {
    setMenuOpen(false);
    setDropdownOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!menuOpen) {
      document.body.removeAttribute("data-menu-open");
      return;
    }
    document.body.setAttribute("data-menu-open", "true");
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setMenuOpen(false);
        triggerRef.current?.focus();
        return;
      }
      if (event.key !== "Tab" || !menuRef.current) return;
      const focusable = menuRef.current.querySelectorAll<HTMLElement>(
        'a[href], button:not([disabled]), input, select, textarea, [tabindex]:not([tabindex="-1"])',
      );
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", onKeyDown);
    const timer = window.setTimeout(() => {
      menuRef.current?.querySelector<HTMLElement>("a, button")?.focus();
    }, 120);
    return () => {
      document.body.removeAttribute("data-menu-open");
      document.removeEventListener("keydown", onKeyDown);
      window.clearTimeout(timer);
    };
  }, [menuOpen]);

  const closeMenu = useCallback(() => {
    setMenuOpen(false);
    triggerRef.current?.focus();
  }, []);

  useEffect(() => {
    if (!dropdownOpen) return;
    const onPointerDown = (event: MouseEvent) => {
      if (!dropdownRef.current?.contains(event.target as Node)) setDropdownOpen(false);
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setDropdownOpen(false);
    };
    document.addEventListener("mousedown", onPointerDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [dropdownOpen]);

  /** Section links carry a hash; on the home page we scroll to them ourselves. */
  const sectionClick = (href: string) => (event: React.MouseEvent<HTMLAnchorElement>) => {
    setDropdownOpen(false);
    setMenuOpen(false);
    if (!href.startsWith("/#") || pathname !== "/") return;
    const target = document.getElementById(href.slice(2));
    if (!target) return;
    event.preventDefault();
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    target.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });
    window.history.replaceState(null, "", href);
  };

  const isActive = (href: string) => {
    const [path, hash] = href.split("#");
    if (hash) return pathname === (path || "/") && activeHash === hash;
    return href === "/" ? pathname === "/" : pathname === href || pathname.startsWith(`${href}/`);
  };

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-[background-color,backdrop-filter,border-color,box-shadow] duration-500 ${
          scrolled || menuOpen
            ? "border-b border-white/10 bg-[rgba(8,28,29,0.82)] shadow-[0_18px_40px_-30px_rgba(0,0,0,0.8)] backdrop-blur-xl"
            : "border-b border-transparent bg-transparent"
        }`}
      >
        <div
          className={`shell flex items-center justify-between gap-8 transition-[height] duration-500 ${
            scrolled ? "h-[68px]" : "h-[84px] lg:h-[92px]"
          }`}
        >
          <div className="relative z-10">
            <Logo tone="light" showTagline={!scrolled} className="[&_svg]:h-9 [&_svg]:w-9" />
          </div>

          <nav aria-label="Primary" className="hidden lg:block">
            <ul className="flex items-center gap-1">
              {primaryNav.map((item) => (
                <li
                  key={item.href}
                  ref={item.children ? dropdownRef : undefined}
                  className="relative"
                  onMouseEnter={() => item.children && setDropdownOpen(true)}
                  onMouseLeave={() => item.children && setDropdownOpen(false)}
                >
                  {item.children ? (
                    <>
                      <button
                        type="button"
                        aria-expanded={dropdownOpen}
                        aria-haspopup="true"
                        onClick={() => setDropdownOpen((v) => !v)}
                        className={`group flex items-center gap-1.5 px-3.5 py-2 text-[0.7rem] font-medium uppercase tracking-[0.17em] transition-colors duration-200 ${
                          isActive(item.href) ? "text-mint" : "text-ivory/78 hover:text-ivory"
                        }`}
                      >
                        <span className="relative">
                          {item.label}
                          <span
                            className={`absolute -bottom-1.5 left-0 h-px w-full origin-left bg-jade transition-transform duration-300 ${
                              isActive(item.href) ? "scale-x-100" : "scale-x-0 group-hover:scale-x-100"
                            }`}
                          />
                        </span>
                        <ChevronDown
                          size={12}
                          className={`transition-transform duration-300 ${dropdownOpen ? "rotate-180" : ""}`}
                        />
                      </button>
                      <div
                        className={`absolute left-0 top-full w-60 origin-top border border-white/10 bg-[rgba(10,32,33,0.97)] p-2 backdrop-blur-xl transition-all duration-200 ${
                          dropdownOpen
                            ? "pointer-events-auto translate-y-1 opacity-100"
                            : "pointer-events-none translate-y-0 opacity-0"
                        }`}
                      >
                        <ul>
                          {item.children.map((child) => (
                            <li key={child.href}>
                              <Link
                                href={child.href}
                                onClick={sectionClick(child.href)}
                                className="block px-3.5 py-2.5 text-[0.72rem] uppercase tracking-[0.13em] text-ivory/70 transition-colors hover:bg-white/5 hover:text-mint"
                              >
                                {child.label}
                              </Link>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </>
                  ) : (
                    <Link
                      href={item.href}
                      onClick={sectionClick(item.href)}
                      aria-current={isActive(item.href) ? "true" : undefined}
                      className={`group flex items-center px-3.5 py-2 text-[0.7rem] font-medium uppercase tracking-[0.17em] transition-colors duration-200 ${
                        isActive(item.href) ? "text-mint" : "text-ivory/78 hover:text-ivory"
                      }`}
                    >
                      <span className="relative">
                        {item.label}
                        <span
                          className={`absolute -bottom-1.5 left-0 h-px w-full origin-left bg-jade transition-transform duration-300 ${
                            isActive(item.href) ? "scale-x-100" : "scale-x-0 group-hover:scale-x-100"
                          }`}
                        />
                      </span>
                    </Link>
                  )}
                </li>
              ))}
            </ul>
          </nav>

          <div className="hidden items-center gap-7 lg:flex">
            <Link
              href="/#contact"
              onClick={sectionClick("/#contact")}
              className="group relative text-[0.7rem] font-medium uppercase tracking-[0.17em] text-ivory/78 transition-colors hover:text-ivory"
            >
              Contact
              <span className="absolute -bottom-1.5 left-0 h-px w-full origin-left scale-x-0 bg-jade transition-transform duration-300 group-hover:scale-x-100" />
            </Link>
            <Link
              href="/#enquiry-form"
              onClick={sectionClick("/#enquiry-form")}
              className="btn btn-jade !min-h-[2.7rem] !px-5 !text-[0.66rem]"
            >
              Enquire Now
            </Link>
          </div>

          <button
            ref={triggerRef}
            type="button"
            onClick={() => setMenuOpen(true)}
            aria-expanded={menuOpen}
            aria-controls="mobile-menu"
            aria-label="Open menu"
            className="relative z-10 flex h-11 w-11 items-center justify-center border border-white/20 text-ivory transition-colors hover:border-jade/60 hover:text-mint lg:hidden"
          >
            <Menu size={20} />
          </button>
        </div>
      </header>

      {/* Mobile menu */}
      <div
        id="mobile-menu"
        ref={menuRef}
        role="dialog"
        aria-modal="true"
        aria-label="Main menu"
        aria-hidden={!menuOpen}
        className={`fixed inset-0 z-[70] flex flex-col bg-ink transition-[opacity,visibility] duration-500 lg:hidden ${
          menuOpen ? "visible opacity-100" : "invisible opacity-0"
        }`}
      >
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -right-24 top-10 h-[26rem] w-[26rem] rounded-full bg-jade/10 blur-[90px]" />
          <div className="absolute inset-x-0 top-0 h-full grid-lines opacity-40" />
        </div>

        <div className="relative flex h-[84px] shrink-0 items-center justify-between px-[var(--gutter)]">
          <Logo tone="light" asLink={false} />
          <button
            type="button"
            onClick={closeMenu}
            aria-label="Close menu"
            className="flex h-11 w-11 items-center justify-center border border-white/20 text-ivory transition-colors hover:border-jade/60 hover:text-mint"
          >
            <Close size={20} />
          </button>
        </div>

        <div className="relative flex flex-1 flex-col justify-between overflow-y-auto px-[var(--gutter)] pb-10">
          <nav aria-label="Mobile" className="pt-6">
            <ul className="flex flex-col">
              {primaryNav.map((item, index) => (
                <li
                  key={item.href}
                  style={{ transitionDelay: menuOpen ? `${140 + index * 55}ms` : "0ms" }}
                  className={`border-b border-white/10 transition-all duration-500 ${
                    menuOpen ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"
                  }`}
                >
                  <Link
                    href={item.href}
                    onClick={sectionClick(item.href)}
                    className="group flex items-baseline justify-between py-5"
                  >
                    <span className="font-serif text-[2rem] font-light leading-none text-ivory transition-colors group-hover:text-mint">
                      {item.label}
                    </span>
                    <span className="mono-label text-jade/60">0{index + 1}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div
            style={{ transitionDelay: menuOpen ? "460ms" : "0ms" }}
            className={`mt-9 transition-all duration-500 ${
              menuOpen ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"
            }`}
          >
            <Link
              href="/#enquiry-form"
              onClick={sectionClick("/#enquiry-form")}
              className="btn btn-jade w-full"
            >
              Enquire Now
            </Link>
            <div className="mt-7 space-y-1.5 text-[0.8rem] text-ivory/55">
              <p className="eyebrow !text-[0.58rem] !text-mint/70">Get in touch</p>
              <a href={`mailto:${siteConfig.contact.email}`} className="block pt-2 text-ivory/85 transition-colors hover:text-mint">
                {siteConfig.contact.email}
              </a>
              <a href={`tel:${siteConfig.contact.phoneHref}`} className="block text-ivory/85 transition-colors hover:text-mint">
                {siteConfig.contact.phone}
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

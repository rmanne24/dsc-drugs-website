import Link from "next/link";
import type { ReactNode } from "react";
import { SectionLabel } from "@/components/ui";

export function PageHero({
  label,
  title,
  copy,
  meta,
  children,
}: {
  label: string;
  title: ReactNode;
  copy?: ReactNode;
  meta?: { label: string; value: string }[];
  children?: ReactNode;
}) {
  return (
    <section className="relative isolate overflow-hidden bg-ink pb-14 pt-[7.5rem] text-ivory sm:pb-16 lg:pb-20 lg:pt-[9.5rem]">
      <div className="pointer-events-none absolute inset-0 grid-lines opacity-40" aria-hidden="true" />
      <div
        className="pointer-events-none absolute -right-32 -top-24 h-[34rem] w-[34rem] rounded-full bg-jade/[0.08] blur-[120px]"
        aria-hidden="true"
      />

      <div className="shell relative">
        <nav aria-label="Breadcrumb" className="mb-8">
          <ol className="flex items-center gap-2 text-[0.6rem] uppercase tracking-[0.16em] text-ivory/35">
            <li>
              <Link href="/" className="transition-colors hover:text-mint">
                Home
              </Link>
            </li>
            <li aria-hidden="true" className="text-ivory/20">
              /
            </li>
            <li className="text-ivory/60" aria-current="page">
              {label}
            </li>
          </ol>
        </nav>

        <div className="grid gap-10 lg:grid-cols-[1.1fr_0.9fr] lg:items-end">
          <div>
            <SectionLabel invert>{label}</SectionLabel>
            <h1 className="display-sm mt-6 max-w-[24ch] text-ivory">{title}</h1>
          </div>
          <div>
            {copy && <p className="max-w-[46ch] text-[0.95rem] leading-relaxed text-ivory/55">{copy}</p>}
            {children}
          </div>
        </div>

        {meta && meta.length > 0 && (
          <dl className="mt-12 grid gap-px overflow-hidden border-t border-white/10 sm:grid-cols-2 lg:grid-cols-4">
            {meta.map((item) => (
              <div key={item.label} className="pt-5 sm:pr-6">
                <dt className="text-[0.58rem] uppercase tracking-[0.18em] text-ivory/35">{item.label}</dt>
                <dd className="mt-1.5 font-serif text-[1.35rem] leading-tight text-ivory/85">{item.value}</dd>
              </div>
            ))}
          </dl>
        )}
      </div>
    </section>
  );
}

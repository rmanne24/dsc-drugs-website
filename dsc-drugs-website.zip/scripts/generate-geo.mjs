// One-off build script: samples land coordinates from Natural Earth 110m data
// so the globe and dotted world map can render without shipping a heavy geo runtime.
// Run with: npm run geo
import fs from "node:fs";
import path from "node:path";
import { feature } from "topojson-client";

const root = process.cwd();
const topology = JSON.parse(
  fs.readFileSync(path.join(root, "node_modules/world-atlas/countries-110m.json"), "utf8"),
);
const land = feature(topology, topology.objects.countries);

const polygons = [];
for (const f of land.features) {
  const geom = f.geometry;
  if (!geom) continue;
  const groups = geom.type === "Polygon" ? [geom.coordinates] : geom.coordinates;
  for (const rings of groups) {
    const outer = rings[0];
    let minLon = 180,
      maxLon = -180,
      minLat = 90,
      maxLat = -90;
    for (const [lon, lat] of outer) {
      if (lon < minLon) minLon = lon;
      if (lon > maxLon) maxLon = lon;
      if (lat < minLat) minLat = lat;
      if (lat > maxLat) maxLat = lat;
    }
    polygons.push({ ring: outer, minLon, maxLon, minLat, maxLat });
  }
}

function inRing(lon, lat, ring) {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const [xi, yi] = ring[i];
    const [xj, yj] = ring[j];
    if (yi > lat !== yj > lat && lon < ((xj - xi) * (lat - yi)) / (yj - yi) + xi) {
      inside = !inside;
    }
  }
  return inside;
}

function isLand(lon, lat) {
  for (const p of polygons) {
    if (lon < p.minLon || lon > p.maxLon || lat < p.minLat || lat > p.maxLat) continue;
    if (inRing(lon, lat, p.ring)) return true;
  }
  return false;
}

// Fibonacci sphere distribution gives evenly spaced dots on the globe.
const TOTAL = 26000;
const golden = Math.PI * (3 - Math.sqrt(5));
const points = [];
for (let i = 0; i < TOTAL; i++) {
  const y = 1 - (i / (TOTAL - 1)) * 2;
  const lat = Math.asin(y) * (180 / Math.PI);
  const lon = (((i * golden * 180) / Math.PI) % 360) - 180;
  if (isLand(lon, lat)) {
    points.push([Math.round(lat * 10) / 10, Math.round(lon * 10) / 10]);
  }
}

const outDir = path.join(root, "lib/geo");
fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, "land-dots.json"), JSON.stringify(points));
console.log(`Wrote ${points.length} land points (${(fs.statSync(path.join(outDir, "land-dots.json")).size / 1024).toFixed(1)} KB)`);

import type { Metadata } from "next";
import { PageHero } from "@/components/PageHero";
import { siteConfig } from "@/lib/site";

export const metadata: Metadata = {
  title: "Terms of Use",
  description:
    "Terms governing use of the DSC Drugs website, including the status of catalogue and market information.",
  alternates: { canonical: "/terms" },
};

const sections = [
  {
    title: "Website purpose",
    body: "This website provides information about DSC Drugs as a pharmaceutical trading company and allows visitors to submit business enquiries. It is not an offer, quotation or contract, and no supply commitment arises from browsing it.",
  },
  {
    title: "Catalogue information",
    body: "Catalogue records may include clearly labelled placeholders while verified company data is being prepared. Product availability, specifications, documentation and regulatory status are confirmed only in a written commercial exchange.",
  },
  {
    title: "Global presence visualisation",
    body: "The interactive globe and market listings are illustrative. They do not represent confirmed export markets, offices, warehousing or legal presence in any jurisdiction.",
  },
  {
    title: "No manufacturing claim",
    body: "DSC Drugs is a trading company. Nothing on this site should be read as a claim of manufacturing facilities, production capacity, in-house research or certification ownership.",
  },
  {
    title: "Acceptable use",
    body: "You agree not to use this website to submit false, misleading or unlawful enquiries, to attempt unauthorised access, or to interfere with its operation. Automated submissions may be rate-limited or blocked.",
  },
  {
    title: "Intellectual property",
    body: "Text, layout and brand assets on this site belong to DSC Drugs unless otherwise credited. You may not reproduce them for commercial use without written permission.",
  },
  {
    title: "Limitation of liability",
    body: "Information is provided in good faith but without warranty of completeness or fitness for a particular purpose. Commercial decisions should rely on the written terms of an engagement, not on this website.",
  },
];

export default function TermsPage() {
  return (
    <>
      <PageHero
        label="Terms of use"
        title={
          <>
            Clear terms for a <span className="serif-italic text-mint">clear relationship.</span>
          </>
        }
        copy={
          <>
            These terms explain the status of information published on this website. They are a working
            draft pending legal review in the company&rsquo;s registered jurisdiction.
          </>
        }
        meta={[
          { label: "Last updated", value: "Draft — pending review" },
          { label: "Company", value: siteConfig.legalName },
          { label: "Governing law", value: "To be confirmed" },
        ]}
      />

      <section className="section bg-ivory">
        <div className="shell grid gap-12 lg:grid-cols-[0.32fr_0.68fr]">
          <aside>
            <p className="mono-label">Contents</p>
            <ol className="mt-4 space-y-2 border-l border-ink/12 pl-4">
              {sections.map((section, index) => (
                <li key={section.title} className="text-[0.82rem] leading-relaxed text-ink/50">
                  <span className="mr-1.5 font-serif text-ink/30">{String(index + 1).padStart(2, "0")}</span>
                  {section.title}
                </li>
              ))}
            </ol>
            <div className="mt-8 border border-[#c9a86a]/40 bg-[#c9a86a]/10 p-4">
              <p className="text-[0.6rem] uppercase tracking-[0.14em] text-[#7a6636]">Draft notice</p>
              <p className="mt-2 text-[0.78rem] leading-relaxed text-ink/60">
                Registration number, registered office and governing law must be supplied by the company
                before these terms are published.
              </p>
            </div>
          </aside>

          <div className="max-w-[62ch]">
            {sections.map((section, index) => (
              <article key={section.title} className="border-t border-ink/10 py-7 first:border-t-0 first:pt-0">
                <p className="mono-label text-ink/30">{String(index + 1).padStart(2, "0")}</p>
                <h2 className="mt-2 font-serif text-[1.45rem] text-ink">{section.title}</h2>
                <p className="mt-3 text-[0.9rem] leading-relaxed text-grey">{section.body}</p>
              </article>
            ))}
            <p className="border-t border-ink/10 pt-6 text-[0.85rem] leading-relaxed text-grey">
              Questions about these terms can be sent to{" "}
              <a href={`mailto:${siteConfig.contact.email}`} className="text-ink underline underline-offset-4">
                {siteConfig.contact.email}
              </a>
              .
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

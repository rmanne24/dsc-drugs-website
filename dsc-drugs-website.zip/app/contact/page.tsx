import { redirect } from "next/navigation";

/** The enquiry form now lives on the home page; keep old links working. */
export default function ContactPage() {
  redirect("/#enquiry-form");
}

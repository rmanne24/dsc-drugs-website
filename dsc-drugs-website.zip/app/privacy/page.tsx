import type { Metadata } from "next";
import { PageHero } from "@/components/PageHero";
import { siteConfig } from "@/lib/site";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description:
    "How DSC Drugs handles information submitted through this website, including enquiry details and basic technical data.",
  alternates: { canonical: "/privacy" },
  robots: { index: true, follow: true },
};

const sections = [
  {
    title: "Information we collect",
    body: "When you submit an enquiry, we receive the details you choose to provide: your name, business email, company, country, enquiry type, product of interest and message. We do not ask for payment details through this website.",
  },
  {
    title: "How we use it",
    body: "Enquiry details are used only to respond to your request and to maintain a record of the commercial conversation. We do not sell personal information, and we do not add you to marketing lists without a separate opt-in.",
  },
  {
    title: "Enquiry list stored in your browser",
    body: "Products you add to the enquiry list are stored in your browser's local storage so the list survives page changes. This data stays on your device until you clear the list or your browser storage.",
  },
  {
    title: "Third-party services",
    body: "Enquiries may be delivered through an email or automation provider acting as a data processor. Hosting and analytics infrastructure may process basic technical data such as IP address and browser type for security and performance.",
  },
  {
    title: "Retention",
    body: "Commercial correspondence is retained for as long as needed to support the business relationship and any legal or regulatory obligation that applies to it.",
  },
  {
    title: "Your choices",
    body: "You can request access to, correction of, or deletion of the enquiry information we hold by writing to the email address below. We will respond within a reasonable period.",
  },
];

export default function PrivacyPage() {
  return (
    <>
      <PageHero
        label="Privacy policy"
        title={
          <>
            Your information, <span className="serif-italic text-mint">handled carefully.</span>
          </>
        }
        copy={
          <>
            This policy describes how enquiry information is handled on this website. It is a working
            draft and should be reviewed against the company&rsquo;s registered jurisdiction before launch.
          </>
        }
        meta={[
          { label: "Last updated", value: "Draft — pending review" },
          { label: "Controller", value: siteConfig.legalName },
          { label: "Contact", value: siteConfig.contact.email },
        ]}
      />

      <section className="section bg-ivory">
        <div className="shell grid gap-12 lg:grid-cols-[0.32fr_0.68fr]">
          <aside>
            <p className="mono-label">On this page</p>
            <ul className="mt-4 space-y-2 border-l border-ink/12 pl-4">
              {sections.map((section) => (
                <li key={section.title} className="text-[0.82rem] leading-relaxed text-ink/50">
                  {section.title}
                </li>
              ))}
            </ul>
            <div className="mt-8 border border-[#c9a86a]/40 bg-[#c9a86a]/10 p-4">
              <p className="text-[0.6rem] uppercase tracking-[0.14em] text-[#7a6636]">Draft notice</p>
              <p className="mt-2 text-[0.78rem] leading-relaxed text-ink/60">
                Company registration details, data-protection officer and jurisdiction are placeholders.
                Legal review is required before publication.
              </p>
            </div>
          </aside>

          <div className="max-w-[62ch]">
            {sections.map((section, index) => (
              <article key={section.title} className="border-t border-ink/10 py-7 first:border-t-0 first:pt-0">
                <p className="mono-label text-ink/30">{String(index + 1).padStart(2, "0")}</p>
                <h2 className="mt-2 font-serif text-[1.45rem] text-ink">{section.title}</h2>
                <p className="mt-3 text-[0.9rem] leading-relaxed text-grey">{section.body}</p>
              </article>
            ))}
            <p className="border-t border-ink/10 pt-6 text-[0.85rem] leading-relaxed text-grey">
              Questions about this policy can be sent to{" "}
              <a href={`mailto:${siteConfig.contact.email}`} className="text-ink underline underline-offset-4">
                {siteConfig.contact.email}
              </a>
              .
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

import { NextResponse } from "next/server";
import { deliverEnquiry, normaliseEnquiry, rateLimit, validateEnquiry } from "@/lib/enquiry";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function clientKey(request: Request) {
  const forwarded = request.headers.get("x-forwarded-for");
  const ip = forwarded?.split(",")[0]?.trim() || request.headers.get("x-real-ip") || "local";
  return `enquiry:${ip}`;
}

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ ok: false, error: "We could not read that submission. Please try again." }, { status: 400 });
  }

  const data = normaliseEnquiry(body);

  // Honeypot: silently accept so bots do not learn anything, but never deliver.
  if (data.website) {
    return NextResponse.json({ ok: true, delivery: "accepted" });
  }

  if (!rateLimit(clientKey(request))) {
    return NextResponse.json(
      { ok: false, error: "Too many enquiries from this connection. Please try again later or email us directly." },
      { status: 429 },
    );
  }

  const errors = validateEnquiry(data);
  if (Object.keys(errors).length > 0) {
    return NextResponse.json({ ok: false, errors }, { status: 422 });
  }

  try {
    const delivery = await deliverEnquiry(data);
    return NextResponse.json({ ok: true, delivery });
  } catch (error) {
    console.error("[enquiry] delivery failed", error);
    return NextResponse.json(
      {
        ok: false,
        error:
          "Your enquiry could not be delivered right now. Please email us directly and we will pick it up straight away.",
      },
      { status: 502 },
    );
  }
}

import Link from "next/link";
import { ArrowRight } from "@/components/Icons";

export default function NotFound() {
  return (
    <section className="relative isolate flex min-h-[80svh] items-center overflow-hidden bg-ink pb-16 pt-[8rem] text-ivory">
      <div className="pointer-events-none absolute inset-0 grid-lines opacity-40" aria-hidden="true" />
      <div className="pointer-events-none absolute -right-24 top-0 h-[32rem] w-[32rem] rounded-full bg-jade/[0.08] blur-[120px]" aria-hidden="true" />

      <div className="shell relative">
        <p className="eyebrow eyebrow-invert">404 — Page not found</p>
        <h1 className="display mt-6 max-w-[16ch] text-ivory">
          This page has <span className="serif-italic text-mint">moved on.</span>
        </h1>
        <p className="mt-6 max-w-[42ch] text-[0.95rem] leading-relaxed text-ivory/55">
          The address you followed does not exist on this site. The catalogue and enquiry form are still
          where you left them.
        </p>
        <div className="mt-9 flex flex-wrap gap-3">
          <Link href="/#products" className="btn btn-jade">
            Browse products
            <ArrowRight size={15} />
          </Link>
          <Link href="/" className="btn btn-outline-invert">
            Return home
          </Link>
        </div>
      </div>
    </section>
  );
}

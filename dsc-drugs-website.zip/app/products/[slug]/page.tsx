import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { CategoryArt } from "@/components/Artwork";
import { EnquiryToggle } from "@/components/EnquiryToggle";
import { ArrowRight, Document, Mail, Shield, WhatsAppIcon } from "@/components/Icons";
import { ProductCard } from "@/components/ProductCard";
import { Reveal } from "@/components/Reveal";
import { SectionLabel } from "@/components/ui";
import { categoryBySlug, productBySlug, products, relatedProducts } from "@/lib/products";
import { siteConfig, whatsappHref, whatsappMessages } from "@/lib/site";

export function generateStaticParams() {
  return products.map((product) => ({ slug: product.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const product = productBySlug(slug);
  if (!product) return { title: "Product not found" };
  return {
    title: product.name,
    description: product.summary,
    alternates: { canonical: `/products/${product.slug}` },
    openGraph: {
      title: `${product.name} · ${siteConfig.name}`,
      description: product.summary,
      url: `/products/${product.slug}`,
    },
  };
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = productBySlug(slug);
  if (!product) notFound();

  const category = categoryBySlug(product.categorySlug);
  const related = relatedProducts(product, 3);
  const whatsappUrl = whatsappHref(whatsappMessages.product(product.name));
  const specifications =
    product.specifications.length > 0
      ? product.specifications
      : [
          { label: "Product name", value: product.name },
          { label: "Category", value: product.category },
          { label: "Segment", value: product.segment },
          { label: "CAS number", value: "To be confirmed" },
          { label: "Specification", value: "To be confirmed" },
          { label: "Sourcing origin", value: "To be confirmed" },
        ];

  return (
    <>
      <section className="relative isolate overflow-hidden bg-ink pb-12 pt-[7rem] text-ivory lg:pt-[8.5rem]">
        <div className="pointer-events-none absolute inset-0 grid-lines opacity-35" aria-hidden="true" />
        <div className="shell relative">
          <nav aria-label="Breadcrumb" className="mb-8">
            <ol className="flex flex-wrap items-center gap-2 text-[0.6rem] uppercase tracking-[0.16em] text-ivory/35">
              <li>
                <Link href="/" className="transition-colors hover:text-mint">Home</Link>
              </li>
              <li aria-hidden="true" className="text-ivory/20">/</li>
              <li>
                <Link href="/#products" className="transition-colors hover:text-mint">Products</Link>
              </li>
              <li aria-hidden="true" className="text-ivory/20">/</li>
              <li className="text-ivory/60" aria-current="page">{product.name}</li>
            </ol>
          </nav>

          <div className="grid gap-10 lg:grid-cols-[1fr_1fr] lg:items-center lg:gap-14">
            <div>
              <SectionLabel invert>{category?.name}</SectionLabel>
              <h1 className="display-sm mt-5 max-w-[20ch] text-ivory">{product.name}</h1>
              <p className="mt-6 max-w-[46ch] text-[0.95rem] leading-relaxed text-ivory/55">{product.summary}</p>

              <dl className="mt-8 grid grid-cols-2 gap-x-6 gap-y-4 border-t border-white/10 pt-6">
                <div>
                  <dt className="text-[0.58rem] uppercase tracking-[0.18em] text-ivory/35">Segment</dt>
                  <dd className="mt-1 text-[0.9rem] text-ivory/80">{product.segment}</dd>
                </div>
                <div>
                  <dt className="text-[0.58rem] uppercase tracking-[0.18em] text-ivory/35">CAS number</dt>
                  <dd className="mt-1 text-[0.9rem] text-ivory/80">{product.cas ?? "To be confirmed"}</dd>
                </div>
                <div>
                  <dt className="text-[0.58rem] uppercase tracking-[0.18em] text-ivory/35">Documentation</dt>
                  <dd className="mt-1 text-[0.9rem] text-ivory/80">On request</dd>
                </div>
                <div>
                  <dt className="text-[0.58rem] uppercase tracking-[0.18em] text-ivory/35">Availability</dt>
                  <dd className="mt-1 text-[0.9rem] text-ivory/80">Confirmed per enquiry</dd>
                </div>
              </dl>

              <div className="mt-8 flex flex-wrap items-center gap-3">
                <Link href="/#enquiry-form" className="btn btn-jade">
                  Enquire about this product
                  <ArrowRight size={15} />
                </Link>
                <div className="[&_button]:border-white/25 [&_button]:text-ivory/80 [&_button:hover]:border-jade [&_button:hover]:text-mint">
                  <EnquiryToggle
                    slug={product.slug}
                    name={product.name}
                    category={category?.name ?? product.category}
                    variant="inline"
                  />
                </div>
              </div>
            </div>

            <div className="relative aspect-[4/3] overflow-hidden border border-white/10">
              <CategoryArt variant={category?.art ?? "molecule"} />
              {product.placeholder && (
                <span className="absolute left-4 top-4 border border-white/40 bg-ink/50 px-2.5 py-1 text-[0.55rem] uppercase tracking-[0.16em] text-ivory backdrop-blur-sm">
                  Placeholder record
                </span>
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="section bg-ivory">
        <div className="shell grid gap-12 lg:grid-cols-[1.15fr_0.85fr] lg:gap-16">
          <div>
            <Reveal>
              <h2 className="heading-serif text-ink">Overview</h2>
              <p className="mt-4 max-w-[62ch] text-[0.95rem] leading-relaxed text-grey">{product.overview}</p>
            </Reveal>

            <Reveal delay={100} className="mt-10">
              <h2 className="heading-serif text-ink">Specifications</h2>
              <dl className="mt-4 divide-y divide-ink/10 border-y border-ink/10">
                {specifications.map((spec) => (
                  <div key={spec.label} className="grid grid-cols-2 gap-4 py-3.5">
                    <dt className="text-[0.7rem] uppercase tracking-[0.13em] text-ink/45">{spec.label}</dt>
                    <dd className="text-[0.9rem] text-ink/85">{spec.value}</dd>
                  </div>
                ))}
              </dl>
              <p className="mt-3 text-[0.68rem] uppercase tracking-[0.13em] text-ink/35">
                Specifications are published only after verification with our sourcing partner.
              </p>
            </Reveal>

            {product.placeholder && (
              <Reveal delay={140} className="mt-10">
                <div className="border-l-2 border-jade-deep/60 bg-paper px-5 py-4">
                  <p className="text-[0.85rem] leading-relaxed text-grey">
                    <strong className="font-semibold text-ink">This is a placeholder record.</strong> It
                    exists to show how verified product data will appear. No specification, regulatory
                    approval or availability is implied.
                  </p>
                </div>
              </Reveal>
            )}
          </div>

          <aside className="space-y-5">
            <Reveal delay={80}>
              <div className="border border-ink/12 bg-paper p-5">
                <p className="mono-label">Documentation</p>
                <ul className="mt-4 space-y-3">
                  {(product.documents.length > 0
                    ? product.documents
                    : [
                        { label: "Certificate of Analysis", status: "on-request" as const },
                        { label: "Certificate of Origin", status: "on-request" as const },
                        { label: "Safety Data Sheet", status: "not-available" as const },
                      ]
                  ).map((doc) => (
                    <li key={doc.label} className="flex items-start gap-3">
                      <span className="mt-0.5 text-jade-deep">
                        <Document size={15} />
                      </span>
                      <div className="flex-1">
                        <p className="text-[0.85rem] text-ink">{doc.label}</p>
                        <p className="text-[0.62rem] uppercase tracking-[0.13em] text-ink/35">
                          {doc.status === "provided"
                            ? "Available on request"
                            : doc.status === "on-request"
                              ? "Shared per enquiry"
                              : "Not currently available"}
                        </p>
                      </div>
                    </li>
                  ))}
                </ul>
                <p className="mt-4 border-t border-ink/10 pt-3 text-[0.62rem] leading-relaxed text-ink/40">
                  Documentation is coordinated with our sourcing partner and confirmed per destination
                  market.
                </p>
              </div>
            </Reveal>

            <Reveal delay={140}>
              <div className="border border-ink/12 bg-ivory-deep p-5">
                <p className="mono-label">Talk to the team</p>
                <p className="mt-3 text-[0.85rem] leading-relaxed text-grey">
                  Share your requirement, destination and volume and we will confirm sourcing and
                  documentation.
                </p>
                <a
                  href={`mailto:${siteConfig.contact.email}?subject=${encodeURIComponent(`Enquiry: ${product.name}`)}`}
                  className="mt-4 inline-flex items-center gap-2 text-[0.7rem] font-semibold uppercase tracking-[0.13em] text-ink transition-colors hover:text-jade-deep"
                >
                  <Mail size={14} />
                  {siteConfig.contact.email}
                </a>
                {whatsappUrl && (
                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-2.5 flex items-center gap-2 text-[0.7rem] font-semibold uppercase tracking-[0.13em] text-ink transition-colors hover:text-jade-deep"
                  >
                    <WhatsAppIcon size={14} />
                    WhatsApp about this product
                  </a>
                )}
                <p className="mt-3 flex items-start gap-2 text-[0.62rem] leading-relaxed text-ink/40">
                  <Shield size={13} className="mt-0.5 shrink-0" />
                  We are a trading company. Manufacturing and certification are not claimed.
                </p>
              </div>
            </Reveal>
          </aside>
        </div>

        <div className="shell mt-16">
          <div className="flex items-end justify-between gap-6 border-t border-ink/12 pt-8">
            <h2 className="heading-serif text-ink">Related records</h2>
            <Link
              href="/#products"
              className="inline-flex items-center gap-1.5 text-[0.62rem] font-semibold uppercase tracking-[0.14em] text-ink/50 transition-colors hover:text-ink"
            >
              All products
              <ArrowRight size={13} />
            </Link>
          </div>
          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {related.map((item, index) => (
              <Reveal key={item.slug} delay={index * 70}>
                <ProductCard product={item} index={index} />
              </Reveal>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

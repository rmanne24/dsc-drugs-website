import { redirect } from "next/navigation";

/** The catalogue now lives on the home page; keep old links working. */
export default function ProductsPage() {
  redirect("/#catalogue");
}

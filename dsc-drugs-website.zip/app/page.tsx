import Link from "next/link";
import type { Metadata } from "next";
import { AboutArt, CategoryArt, PortraitArt } from "@/components/Artwork";
import { Catalogue } from "@/components/Catalogue";
import { ContactSection } from "@/components/ContactSection";
import { Globe } from "@/components/Globe";
import { GlobePanel } from "@/components/GlobePanel";
import { ArrowDown, ArrowRight, ArrowUpRight, Check, Document, Handshake, Layers, Shield } from "@/components/Icons";
import { Reveal } from "@/components/Reveal";
import { LinkButton, SectionIntro, SectionLabel } from "@/components/ui";
import { leadership } from "@/lib/leadership";
import { markets } from "@/lib/markets";
import { categories } from "@/lib/products";

export const metadata: Metadata = {
  title: "Pharmaceutical Trading & Global Sourcing",
  description:
    "DSC Drugs is a pharmaceutical trading company connecting verified products, qualified trade partners and international markets — with documentation handled at every step.",
  alternates: { canonical: "/" },
};

const principles = [
  {
    icon: Handshake,
    title: "Relationship-led trading",
    copy: "We work through established trade relationships rather than owning production. Every engagement starts with a conversation about requirement, destination and documentation.",
  },
  {
    icon: Layers,
    title: "Portfolio, not promises",
    copy: "Categories are published only once they can be sourced credibly. Where detail is still being verified, the site says so.",
  },
  {
    icon: Shield,
    title: "Documentation first",
    copy: "Commercial paperwork, product documentation and regulatory requirements are reviewed and shared per market before an order is confirmed.",
  },
];

const inScope = [
  "Sourcing pharmaceutical products through qualified trade partners",
  "Commercial coordination between buyers and sourcing partners",
  "Documentation and regulatory paperwork requirements per market",
  "Cross-border supply support for distributors and institutions",
  "Long-term trading relationships built on repeat business",
];

const outOfScope = [
  "Manufacturing facilities or production lines",
  "In-house research and development laboratories",
  "Manufacturing certifications or capacity claims",
  "Unverified customer names, volumes or revenues",
];

const register = [
  {
    label: "Certificate of Analysis (CoA)",
    detail: "Issued by the sourcing partner for the specific batch and specification.",
    status: "Shared per product",
  },
  {
    label: "Certificate of Origin (CoO)",
    detail: "Coordinated with the supplier for the shipment and destination.",
    status: "Per shipment",
  },
  {
    label: "Material Safety Data Sheet (MSDS)",
    detail: "Provided where applicable to the product category.",
    status: "Where applicable",
  },
  {
    label: "Regulatory documentation",
    detail: "Reviewed against the requirements of the destination market.",
    status: "Reviewed per market",
  },
  {
    label: "Commercial documentation",
    detail: "Invoice, packing list and transport documents prepared per order.",
    status: "Per order",
  },
];

const process = [
  { step: "01", title: "Requirement", copy: "Product, specification, quantity and destination are confirmed in writing." },
  { step: "02", title: "Sourcing", copy: "A qualified trade partner confirms availability and documentary support." },
  { step: "03", title: "Review", copy: "Documentation is checked against the requirement and destination market." },
  { step: "04", title: "Release", copy: "Commercial terms are agreed and the shipment is coordinated to dispatch." },
];

const contactGuidance = [
  {
    title: "Product enquiries",
    copy: "Include the product name or category, required specification and quantity so sourcing can be confirmed quickly.",
  },
  {
    title: "Supply & partnership",
    copy: "Tell us who you are, the markets you serve, and the nature of the relationship you have in mind.",
  },
  {
    title: "Documentation",
    copy: "If you need specific certificates or regulatory paperwork, name the destination market in your message.",
  },
];

export default function HomePage() {
  return (
    <>
      {/* ---------------------------------------------------------------- HERO */}
      <section className="relative isolate overflow-hidden bg-ink pb-10 pt-[6.5rem] text-ivory sm:pb-12 lg:min-h-[92svh] lg:pt-[7rem]">
        <div className="pointer-events-none absolute inset-0 grid-lines opacity-50" aria-hidden="true" />
        <div
          className="pointer-events-none absolute -right-[18%] top-[8%] h-[42rem] w-[42rem] rounded-full bg-jade/[0.09] blur-[130px] lg:right-[-6%]"
          aria-hidden="true"
        />
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-ink-deep/80 to-transparent" aria-hidden="true" />

        <div className="shell relative grid items-center gap-10 lg:grid-cols-[1.05fr_0.95fr] lg:gap-6">
          <div className="relative z-10 max-w-[36rem]">
            <p className="eyebrow eyebrow-invert animate-rise">Pharmaceutical trading</p>

            <h1 className="display mt-6 text-ivory lg:text-[clamp(2.7rem,4.6vw,4.45rem)]">
              <span className="line-mask">
                <span style={{ "--delay": "120ms" } as React.CSSProperties}>Connecting</span>
              </span>
              <span className="line-mask">
                <span style={{ "--delay": "220ms" } as React.CSSProperties}>pharmaceutical</span>
              </span>
              <span className="line-mask">
                <span style={{ "--delay": "320ms" } as React.CSSProperties}>
                  supply, <span className="serif-italic text-mint">worldwide.</span>
                </span>
              </span>
            </h1>

            <p
              className="mt-6 max-w-[38ch] animate-rise text-[0.98rem] leading-relaxed text-ivory/60 sm:text-[1.05rem]"
              style={{ "--delay": "520ms" } as React.CSSProperties}
            >
              A trading house for pharmaceutical products — sourcing through qualified partners,
              managing documentation, and bringing supply and demand together across borders.
            </p>

            <div
              className="mt-8 flex flex-col gap-3 animate-rise sm:flex-row sm:items-center sm:gap-4"
              style={{ "--delay": "640ms" } as React.CSSProperties}
            >
              <LinkButton href="/#products" variant="jade">
                Explore the portfolio
              </LinkButton>
              <LinkButton href="/#enquiry-form" variant="outline-invert" arrow={false}>
                Start an enquiry
              </LinkButton>
            </div>

            <div
              className="mt-8 flex flex-wrap gap-x-8 gap-y-3 border-t border-white/10 pt-5 animate-fade"
              style={{ "--delay": "820ms" } as React.CSSProperties}
            >
              {["APIs & intermediates", "Injectables", "Oral solids", "Specialty"].map((item) => (
                <span
                  key={item}
                  className="text-[0.62rem] font-medium uppercase tracking-[0.16em] text-ivory/40"
                >
                  {item}
                </span>
              ))}
            </div>
          </div>

          <div className="relative animate-fade" style={{ "--delay": "300ms" } as React.CSSProperties}>
            <Globe
              markers={markets.slice(0, 5)}
              className="mx-auto aspect-square w-full max-w-[34rem] lg:max-w-none"
              ariaLabel="Rotating globe illustrating cross-border pharmaceutical trade"
            />
            <div className="pointer-events-none absolute bottom-2 left-0 hidden items-center gap-3 lg:flex">
              <span className="h-px w-10 bg-jade/50" />
              <span className="text-[0.58rem] uppercase tracking-[0.22em] text-ivory/40">
                Trading across borders
              </span>
            </div>
          </div>
        </div>

        <div className="shell relative mt-7 hidden items-center justify-between lg:[@media(min-height:1000px)]:flex">
          <Link
            href="#about"
            className="group inline-flex items-center gap-3 text-[0.6rem] uppercase tracking-[0.2em] text-ivory/40 transition-colors hover:text-mint"
          >
            <span className="scroll-hint-line" />
            Scroll to explore
          </Link>
          <div className="flex items-center gap-2 text-[0.6rem] uppercase tracking-[0.2em] text-ivory/30">
            <ArrowDown size={13} className="text-jade/60" />
            Trading · Sourcing · Documentation
          </div>
        </div>
      </section>

      {/* --------------------------------------------------------------- ABOUT */}
      <section id="about" className="section scroll-mt-24 bg-ivory">
        <div className="shell">
          <div className="grid items-center gap-14 lg:grid-cols-2 lg:gap-20">
            <Reveal className="relative order-2 lg:order-1">
              <div className="relative aspect-[4/5] w-full overflow-hidden sm:aspect-[5/6]">
                <AboutArt />
                <span className="absolute left-5 top-5 border border-white/20 bg-ink/40 px-3 py-1.5 text-[0.55rem] uppercase tracking-[0.18em] text-ivory/60 backdrop-blur">
                  DSC Drugs · Company profile
                </span>
              </div>
              <div className="absolute -bottom-6 -right-2 hidden max-w-[15rem] border border-ink/10 bg-paper p-5 shadow-[0_24px_50px_-32px_rgba(11,34,35,0.5)] sm:block lg:-right-8">
                <p className="mono-label">Our role</p>
                <p className="mt-2 font-serif text-[1.35rem] leading-snug text-ink">
                  A trading company — never a manufacturer.
                </p>
              </div>
            </Reveal>

            <div className="order-1 lg:order-2">
              <SectionIntro
                label="About DSC Drugs"
                title={
                  <>
                    An international trading business built on{" "}
                    <span className="serif-italic text-jade-deep">trust and clarity.</span>
                  </>
                }
              />
              <Reveal delay={220}>
                <p className="mt-6 max-w-[46ch] text-[0.95rem] leading-relaxed text-grey">
                  DSC Drugs operates as a pharmaceutical trading company. We source products through
                  qualified trade partners, coordinate commercial and documentation requirements, and
                  support distribution into the markets our partners serve.
                </p>
              </Reveal>
              <Reveal delay={280}>
                <p className="mt-4 max-w-[46ch] text-[0.95rem] leading-relaxed text-grey">
                  We are deliberately transparent about what sits inside our scope — and what does not.
                  This site publishes verified information only; where details are still being confirmed,
                  it says so.
                </p>
              </Reveal>

              <Reveal delay={340}>
                <div className="mt-9 flex flex-wrap items-center gap-x-8 gap-y-3 text-[0.7rem] uppercase tracking-[0.14em] text-ink/50">
                  <span>Product sourcing</span>
                  <span className="h-px w-6 bg-ink/20" />
                  <span>Commercial coordination</span>
                  <span className="h-px w-6 bg-ink/20" />
                  <span>Documentation</span>
                </div>
              </Reveal>

              <Reveal delay={400} className="mt-9">
                <LinkButton href="/#products" variant="outline">
                  Explore the portfolio
                </LinkButton>
              </Reveal>
            </div>
          </div>

          <div className="mt-16 grid gap-px divide-y divide-ink/10 border-y border-ink/10 md:grid-cols-2 md:divide-x md:divide-y-0">
            <Reveal className="py-10 md:pr-12">
              <p className="mono-label text-jade-deep">Inside our scope</p>
              <h3 className="mt-3 font-serif text-[1.75rem] text-ink">What we do</h3>
              <ul className="mt-5 space-y-3">
                {inScope.map((item) => (
                  <li key={item} className="flex items-start gap-3 text-[0.88rem] leading-relaxed text-grey">
                    <ArrowRight size={14} className="mt-1 shrink-0 text-jade-deep" />
                    {item}
                  </li>
                ))}
              </ul>
            </Reveal>
            <Reveal delay={90} className="py-10 md:pl-12">
              <p className="mono-label text-ink/40">Outside our scope</p>
              <h3 className="mt-3 font-serif text-[1.75rem] text-ink">What we don&rsquo;t claim</h3>
              <ul className="mt-5 space-y-3">
                {outOfScope.map((item) => (
                  <li key={item} className="flex items-start gap-3 text-[0.88rem] leading-relaxed text-grey">
                    <span className="mt-[0.45rem] h-px w-3.5 shrink-0 bg-ink/30" />
                    {item}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ---------------------------------------------------------- PRINCIPLES */}
      <section className="border-y border-ink/10 bg-paper">
        <div className="shell grid divide-y divide-ink/10 md:grid-cols-3 md:divide-x md:divide-y-0">
          {principles.map((principle, index) => (
            <Reveal key={principle.title} delay={index * 90} className="px-0 py-9 md:px-8 md:py-12 md:first:pl-0 md:last:pr-0">
              <span className="flex h-10 w-10 items-center justify-center rounded-full border border-ink/12 text-jade-deep">
                <principle.icon size={17} />
              </span>
              <h3 className="mt-5 font-serif text-[1.4rem] leading-snug text-ink">{principle.title}</h3>
              <p className="mt-3 text-[0.85rem] leading-relaxed text-grey">{principle.copy}</p>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ------------------------------------------------------------ PRODUCTS */}
      <section id="products" className="section scroll-mt-24 bg-ivory">
        <div className="shell">
          <div className="flex flex-col justify-between gap-8 lg:flex-row lg:items-end">
            <SectionIntro
              label="Product portfolio"
              title={
                <>
                  Categories we trade,
                  <br className="hidden sm:block" /> presented{" "}
                  <span className="serif-italic text-jade-deep">without exaggeration.</span>
                </>
              }
            />
            <Reveal delay={160}>
              <p className="max-w-[30ch] text-[0.78rem] leading-relaxed text-ink/45">
                Search, filter and assemble a combined enquiry without leaving this page.
              </p>
            </Reveal>
          </div>

          <div className="mt-12 grid gap-px overflow-hidden border border-ink/10 bg-ink/10 sm:grid-cols-2 lg:grid-cols-4">
            {categories.map((category, index) => (
              <Reveal key={category.slug} delay={index * 70}>
                <a
                  href="#catalogue"
                  className="group relative flex h-full flex-col bg-paper transition-colors duration-300 hover:bg-white"
                >
                  <div className="relative aspect-[5/4] overflow-hidden bg-ivory-deep zoom-media">
                    <CategoryArt variant={category.art} />
                    <span className="absolute left-4 top-4 font-serif text-xs text-ink/35">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                  </div>
                  <div className="flex flex-1 flex-col p-5">
                    <h3 className="font-serif text-[1.3rem] leading-tight text-ink">{category.name}</h3>
                    <p className="mt-2 text-[0.78rem] leading-relaxed text-grey">{category.short}</p>
                    <span className="mt-4 inline-flex items-center gap-1.5 text-[0.6rem] font-semibold uppercase tracking-[0.15em] text-ink/45 transition-colors group-hover:text-jade-deep">
                      Browse
                      <ArrowUpRight size={12} className="transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </span>
                  </div>
                </a>
              </Reveal>
            ))}
          </div>

          <div className="mt-14">
            <Catalogue />
          </div>
        </div>
      </section>

      {/* -------------------------------------------------------------- GLOBAL */}
      <section id="global-presence" className="section-dark section relative scroll-mt-24 overflow-hidden" aria-labelledby="presence-heading">
        <div className="pointer-events-none absolute inset-0 grid-lines opacity-40" aria-hidden="true" />
        <div className="shell relative">
          <div className="grid gap-8 lg:grid-cols-[1fr_auto] lg:items-end">
            <div>
              <Reveal>
                <SectionLabel invert>Global presence</SectionLabel>
              </Reveal>
              <Reveal delay={80}>
                <h2 id="presence-heading" className="display-sm mt-6 max-w-[22ch] text-ivory">
                  Trade that moves between{" "}
                  <span className="serif-italic text-mint">markets.</span>
                </h2>
              </Reveal>
              <Reveal delay={150}>
                <p className="lede mt-6 max-w-[48ch] text-ivory/55">
                  Our role is to connect requirement with supply across borders. Market hubs shown here
                  are placeholders for the interactive map — confirmed locations will replace them once
                  verified.
                </p>
              </Reveal>
            </div>
            <Reveal delay={200}>
              <LinkButton href="/#contact" variant="outline-invert">
                Discuss a market
              </LinkButton>
            </Reveal>
          </div>

          <Reveal delay={120} className="mt-12 border-t border-white/10 pt-10">
            <GlobePanel markets={markets} />
          </Reveal>

          <div className="mt-12 grid gap-10 lg:grid-cols-[1fr_1fr] lg:gap-16">
            <Reveal>
              <p className="eyebrow eyebrow-invert">Market notes</p>
              <h3 className="mt-5 max-w-[22ch] font-serif text-[1.75rem] leading-snug text-ivory">
                A network is only as good as its{" "}
                <span className="serif-italic text-mint">verification.</span>
              </h3>
              <p className="mt-4 max-w-[44ch] text-[0.88rem] leading-relaxed text-ivory/50">
                We have deliberately not published a list of export countries, customer names or
                volumes. Those claims are easy to make and hard to verify. When DSC Drugs has confirmed
                market coverage, it will appear here with the same restraint.
              </p>
            </Reveal>

            <Reveal delay={100}>
              <div className="border border-white/10 bg-white/[0.03]">
                <div className="border-b border-white/10 px-5 py-4">
                  <p className="mono-label text-mint/70">Regional coverage</p>
                </div>
                <ul className="divide-y divide-white/10">
                  {markets.map((market, index) => (
                    <li key={market.id} className="flex items-start justify-between gap-6 px-5 py-3.5">
                      <div>
                        <p className="text-[0.88rem] font-medium text-ivory/85">{market.region}</p>
                        <p className="mt-0.5 text-[0.7rem] text-ivory/35">
                          {market.coords[0].toFixed(2)}°, {market.coords[1].toFixed(2)}°
                        </p>
                      </div>
                      <span className="shrink-0 border border-white/15 px-2 py-0.5 text-[0.55rem] uppercase tracking-[0.12em] text-ivory/40">
                        {String(index + 1).padStart(2, "0")} · Pending
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          </div>

          <p className="mt-8 flex items-center gap-2 text-[0.6rem] uppercase tracking-[0.16em] text-ivory/25">
            <span className="h-1 w-1 rounded-full bg-jade" />
            Illustrative visualisation — not a statement of confirmed export markets
          </p>
        </div>
      </section>

      {/* ---------------------------------------------------------- MANAGEMENT */}
      <section id="management" className="section scroll-mt-24 bg-ivory" aria-labelledby="management-heading">
        <div className="shell">
          <div className="flex flex-col justify-between gap-8 lg:flex-row lg:items-end">
            <div>
              <Reveal>
                <SectionLabel>The people</SectionLabel>
              </Reveal>
              <Reveal delay={80}>
                <h2 id="management-heading" className="display-sm mt-6 max-w-[24ch]">
                  Led by people who know{" "}
                  <span className="serif-italic text-jade-deep">the trade.</span>
                </h2>
              </Reveal>
            </div>
            <Reveal delay={140}>
              <p className="lede max-w-[34ch] text-[0.9rem]">
                Leadership profiles are being prepared. Names, designations and biographies will be
                published once confirmed by the company.
              </p>
            </Reveal>
          </div>

          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {leadership.map((leader, index) => (
              <Reveal key={leader.id} delay={index * 90}>
                <article className="group h-full border border-ink/10 bg-paper">
                  <div className="relative aspect-[4/5] overflow-hidden zoom-media">
                    <PortraitArt index={String(index + 1).padStart(2, "0")} />
                    <span className="absolute left-4 top-4 border border-ink/15 bg-paper/85 px-2.5 py-1 text-[0.55rem] uppercase tracking-[0.16em] text-ink/50 backdrop-blur-sm">
                      Profile pending
                    </span>
                  </div>
                  <div className="p-5">
                    <h3 className="font-serif text-[1.25rem] text-ink/45">
                      {leader.name ?? "Name to be confirmed"}
                    </h3>
                    <p className="mt-1 text-[0.6rem] uppercase tracking-[0.16em] text-ink/30">
                      {leader.designation ?? "Designation to be confirmed"}
                    </p>
                    <p className="mt-4 text-[0.82rem] leading-relaxed text-grey">
                      {leader.bio ??
                        "A short biography will be added here once verified. Until then, this card intentionally leaves the detail blank."}
                    </p>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>

          <div className="mt-12 grid gap-10 border-t border-ink/12 pt-10 lg:grid-cols-[1fr_1fr] lg:items-center lg:gap-20">
            <div>
              <p className="mono-label">Governance</p>
              <h3 className="mt-3 font-serif text-[1.8rem] leading-snug text-ink">
                Accountability sits with named people.
              </h3>
              <p className="mt-4 max-w-[48ch] text-[0.9rem] leading-relaxed text-grey">
                We do not publish anonymous testimonials or invented credentials. When leadership details
                are provided, each profile will carry a verified name, role and biography — and a direct
                route to that person through the company.
              </p>
            </div>
            <div className="flex flex-wrap gap-3 lg:justify-end">
              <LinkButton href="/#contact" variant="ink">
                Contact the team
              </LinkButton>
              <LinkButton href="/#quality" variant="outline">
                Quality &amp; documentation
              </LinkButton>
            </div>
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------------- QUALITY */}
      <section id="quality" className="section scroll-mt-24 bg-ivory-deep" aria-labelledby="quality-heading">
        <div className="shell grid gap-12 lg:grid-cols-[0.95fr_1.05fr] lg:gap-20">
          <div>
            <Reveal>
              <SectionLabel>Quality &amp; documentation</SectionLabel>
            </Reveal>
            <Reveal delay={80}>
              <h2 id="quality-heading" className="display-sm mt-6 max-w-[20ch]">
                The paperwork matters as much as{" "}
                <span className="serif-italic text-jade-deep">the product.</span>
              </h2>
            </Reveal>
            <Reveal delay={150}>
              <p className="mt-6 max-w-[44ch] text-[0.95rem] leading-relaxed text-grey">
                As a trading company, we coordinate documentation with the partners we source from. We
                do not claim manufacturing certifications or operating facilities, and no certification
                is presented here until it can be verified.
              </p>
            </Reveal>
            <Reveal delay={200}>
              <div className="mt-7 border border-ink/12 bg-paper p-5">
                <p className="flex items-center gap-2 text-[0.62rem] font-semibold uppercase tracking-[0.16em] text-ink/60">
                  <Shield size={15} className="text-jade-deep" />
                  Compliance statement
                </p>
                <p className="mt-3 text-[0.82rem] leading-relaxed text-grey">
                  Regulatory responsibility for import, distribution and use rests with the licensed
                  parties in the destination market. We support the documentation process; we do not
                  replace it.
                </p>
              </div>
            </Reveal>
            <Reveal delay={250} className="mt-7">
              <LinkButton href="/#contact" variant="outline">
                Request documentation
              </LinkButton>
            </Reveal>
          </div>

          <Reveal delay={120}>
            <div className="border border-ink/12 bg-paper">
              <div className="flex items-center justify-between gap-4 border-b border-ink/10 px-5 py-4">
                <p className="mono-label">Documentation register</p>
                <span className="text-[0.58rem] uppercase tracking-[0.14em] text-ink/35">Template</span>
              </div>
              <ul className="divide-y divide-ink/10">
                {register.map((row, index) => (
                  <li key={row.label} className="flex items-start gap-4 px-5 py-4">
                    <span className="mt-0.5 text-jade-deep">
                      <Document size={16} />
                    </span>
                    <div className="flex-1">
                      <p className="text-[0.9rem] font-medium text-ink">{row.label}</p>
                      <p className="mt-1 text-[0.76rem] leading-relaxed text-grey">{row.detail}</p>
                      <p className="mt-1.5 text-[0.58rem] uppercase tracking-[0.13em] text-ink/35">
                        {String(index + 1).padStart(2, "0")} · {row.status}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
              <p className="border-t border-ink/10 px-5 py-3 text-[0.6rem] uppercase tracking-[0.14em] text-ink/30">
                Availability confirmed per enquiry — no certification implied
              </p>
            </div>
          </Reveal>
        </div>

        <div className="shell mt-16">
          <div className="border border-white/10 bg-ink px-6 py-10 sm:px-9">
            <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
              <div>
                <p className="mono-label text-mint/70">How a trade moves</p>
                <h3 className="mt-3 font-serif text-[1.8rem] text-ivory">
                  Four stages, <span className="serif-italic text-mint">no shortcuts.</span>
                </h3>
              </div>
              <p className="flex items-center gap-2 text-[0.62rem] uppercase tracking-[0.15em] text-ivory/35">
                <Check size={13} className="text-jade" />
                Process description, not a certification claim
              </p>
            </div>

            <ol className="mt-9 grid gap-px overflow-hidden border border-white/10 bg-white/10 sm:grid-cols-2 lg:grid-cols-4">
              {process.map((item, index) => (
                <Reveal key={item.step} delay={index * 80} as="li" className="bg-ink p-6">
                  <span className="font-serif text-[1.6rem] text-jade/60">{item.step}</span>
                  <h4 className="mt-3 font-serif text-[1.25rem] text-ivory">{item.title}</h4>
                  <p className="mt-2 text-[0.8rem] leading-relaxed text-ivory/50">{item.copy}</p>
                </Reveal>
              ))}
            </ol>
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------------- CONTACT */}
      <section className="bg-ivory pt-14">
        <div className="shell grid gap-px divide-y divide-ink/10 border-y border-ink/10 py-2 md:grid-cols-3 md:divide-x md:divide-y-0">
          {contactGuidance.map((item, index) => (
            <Reveal key={item.title} delay={index * 70} className="py-5 md:px-8 md:py-4 md:first:pl-0 md:last:pr-0">
              <p className="mono-label text-jade-deep">{String(index + 1).padStart(2, "0")}</p>
              <h2 className="mt-2 font-serif text-[1.25rem] text-ink">{item.title}</h2>
              <p className="mt-2 text-[0.82rem] leading-relaxed text-grey">{item.copy}</p>
            </Reveal>
          ))}
        </div>
      </section>

      <ContactSection />
    </>
  );
}

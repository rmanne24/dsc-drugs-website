import { redirect } from "next/navigation";

/** The site is now one continuous page; keep old links working. */
export default function AboutPage() {
  redirect("/#about");
}

import { ImageResponse } from "next/og";

export const alt = "DSC Drugs — Pharmaceutical Trading & Global Sourcing";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OpenGraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          background: "linear-gradient(135deg, #0B2223 0%, #123234 55%, #07191A 100%)",
          padding: "72px 80px",
          position: "relative",
        }}
      >
        <div
          style={{
            position: "absolute",
            right: -140,
            top: -160,
            width: 620,
            height: 620,
            borderRadius: 9999,
            background: "rgba(115,182,170,0.16)",
          }}
        />
        <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
          <div
            style={{
              width: 56,
              height: 56,
              borderRadius: 9999,
              border: "1px solid rgba(169,209,197,0.6)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <div style={{ width: 14, height: 14, borderRadius: 9999, background: "#73B6AA" }} />
          </div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 10 }}>
            <span style={{ color: "#F3F4F0", fontSize: 34, letterSpacing: 6, fontWeight: 700 }}>DSC</span>
            <span style={{ color: "#A9D1C5", fontSize: 34, letterSpacing: 6, fontWeight: 300 }}>DRUGS</span>
          </div>
        </div>

        <div style={{ display: "flex", flexDirection: "column" }}>
          <span style={{ color: "#A9D1C5", fontSize: 16, letterSpacing: 6, textTransform: "uppercase" }}>
            Pharmaceutical trading
          </span>
          <span
            style={{
              color: "#F3F4F0",
              fontSize: 82,
              lineHeight: 1.02,
              marginTop: 24,
              maxWidth: 900,
              letterSpacing: -1.5,
            }}
          >
            Connecting pharmaceutical supply, worldwide.
          </span>
        </div>

        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            borderTop: "1px solid rgba(255,255,255,0.14)",
            paddingTop: 24,
            color: "rgba(243,244,240,0.55)",
            fontSize: 20,
            letterSpacing: 2,
          }}
        >
          <span>Trading · Sourcing · Documentation</span>
          <span>dscdrugs.com</span>
        </div>
      </div>
    ),
    size,
  );
}
